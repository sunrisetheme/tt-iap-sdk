using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// SAMPLE: Minimal ITikTokRewardHandler implementation.
/// Copy this into your project and adapt it to your game's reward system.
/// </summary>
public class SampleRewardHandler : MonoBehaviour, HS.TikTokSDK.ITikTokRewardHandler
{
    private void Start()
    {
        // Register with the SDK
        HS.TikTokSDK.TikTokSDK.Instance?.RegisterRewardHandler(this);
    }

    public void OnPurchaseRewardsGranted(string productId, List<HS.TikTokSDK.TikTokReward> rewards)
    {
        Debug.Log($"[SampleRewardHandler] Purchase confirmed for product {productId}!");
        ProcessRewards(rewards);
    }

    public void OnPendingRewardsRecovered(string productId, List<HS.TikTokSDK.TikTokReward> rewards)
    {
        Debug.Log($"[SampleRewardHandler] Recovered pending rewards for product {productId}!");
        ProcessRewards(rewards);
    }

    private void ProcessRewards(List<HS.TikTokSDK.TikTokReward> rewards)
    {
        foreach (var reward in rewards)
        {
            switch (reward.type)
            {
                case "hints":
                    Debug.Log($"  → Granting {reward.amount} hints");
                    // YourGame.AddHints(reward.amount);
                    break;

                case "ads_removed":
                    Debug.Log($"  → Removing ads: {reward.value}");
                    // YourGame.SetAdsRemoved(reward.value);
                    break;

                default:
                    Debug.Log($"  → Unknown reward type: {reward.type}");
                    break;
            }
        }
    }
}
