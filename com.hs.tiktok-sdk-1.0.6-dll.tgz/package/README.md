# HS TikTok MiniGame SDK (v1.0.6)

Complete Unity SDK for TikTok MiniGame development — Authentication, In-App Purchases, Cloud Sync, and Anti-Cheat.

## Features

- **Authentication** — one `Login()` call: plugin init, TikTok auth, session. Editor test mode automatic
- **In-App Purchases** — server-authoritative IAP with TikTok payment UI integration
- **Ads** — rewarded and interstitial, driven by a remote per-game waterfall (`ShowAdsRemote`)
- **Missions** — TikTok entrance and shortcut missions behind one `Execute()` API
- **Cloud Sync** — offline-first background save sync (configurable interval)
- **Crash Recovery** — automatic recovery of paid-but-undelivered purchases and refunds
- **Zero Coupling** — interface-based integration, no game-code dependencies

## Installation

### Via Unity Package Manager (Git URL)

```
Window > Package Manager > + > Add package from git URL...
→ https://github.com/your-org/hs-tiktok-sdk.git
```

### Manual

Copy the `HS.TikTokSDK` folder into your Unity project's `Assets/` directory.

## Quick Start

1. **Menu:** `IAP TikTok Setup ▸ Integration Checklist` → **Setup SDK in Scene**,
   then paste your **Game Id** and **Sdk Key** into the checklist. It verifies the
   connection for you.
2. **Code** — this is the whole minimum integration:

```csharp
public class Boot : MonoBehaviour, ITikTokRewardHandler
{
    void Start()
    {
        TikTokSDK.Instance.RegisterRewardHandler(this);        // before login
        TikTokAuth.Instance.Login(r => { if (r.success) StartGame(); });
    }

    public void OnPurchaseRewardsGranted(string id, List<TikTokReward> rw) => Grant(rw);
    public void OnPendingRewardsRecovered(string id, List<TikTokReward> rw) => Grant(rw);
}
```

3. **Use it:** `TikTokIAP.Instance.BuyProduct("1")`, `TikTokAds.ShowAdsRemote("revive", cb)`.

No `TT.InitSDK`, no `TT.Login`, no `#if UNITY_EDITOR` — the same code runs in the
Editor (test mode) and inside TikTok. See `Documentation~/integration_guide.md`
for ads, missions, cloud sync and refunds.

## Requirements

- Unity 2021.3+
- Node.js backend (see backend API contract in docs)
- TikTok Developer Portal app registration
