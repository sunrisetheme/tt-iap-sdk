# Changelog

All notable changes to the **HS TikTok MiniGame SDK for Unity** (`com.hs.tiktok-sdk`)
are documented in this file. The HTML5 build has its own changelog in `js/CHANGELOG.md`.

## [1.0.6] - 2026-08-21

### Added
- **Ads: read the remote config instead of re-parsing it.** `ResolvePlace(label)`
  answers what `ShowAdsRemote` would show right now — the chosen unit, or the
  reason there is none — and walks the whole waterfall with a per-candidate skip
  reason, without showing anything or starting a cooldown. Alongside it:
  `GetPlaceLabels()`, `GetPlacement(label)`, `GetCooldownRemaining(label, adId)`,
  `GetActivePlacementsOfType(type)`, `GetAdLogs()` and the parsed `Config`. Games
  were parsing `RawIaaConfigJson` themselves against a schema they do not own.
- **`AdResult` now names the ad.** `ad_id`, `ad_type`, `place_label` and `context`
  are filled on every callback, failures included. A game calling `ShowAdsRemote`
  never chose the unit, so without these it could not log which one paid, tell two
  units at one place apart, or put an id in a support ticket.
- **Ads no longer die with login.** `iaa_config` arrived only inside the login
  response, so a game that used TikTok's own login, or none at all, had an empty
  waterfall and got `404` for every place — though showing an ad needs no session
  and never touches our backend. `ShowAdsRemote` now silently fetches the config
  once from `POST /api/ads/config` when none has arrived, and reports `503` if
  that fetch fails instead of blaming the place label. `LoadRemoteConfig()` does
  it up front for ads-only games, and `IsConfigLoaded` reports the state.
- **`TikTokAds.ShowAdOfType(type, context, cb)`** — shows the first active unit of a
  type. `ShowAd` requires a unit id, so a request carrying only `type` was rejected
  with no supported alternative.
- **`TikTokAuth.Login(onResult)` — the SDK now owns the whole login.** One call
  initialises TikTok's plugin, obtains an auth code, exchanges it, and reports a
  single result. Games no longer call `TT.InitSDK` or `TT.Login` at all.

  The old split was justified as "the plugin belongs to the game", but the SDK
  already calls `TT.CreateRewardedVideoAd`, `TT.AddShortcut` and
  `TT.StartEntranceMission` — login was the one place left where it asked the game
  to make the call for it. Not a principle, an inconsistency, and one every
  partner rediscovered through a login that worked in the Editor and failed on a
  phone.
- **A missing plugin is now its own login failure.** In a TikTok build without
  `TTSDK_MIX_ENGINE`, `Login` reported `TikTokRejected` — flagged retryable, though
  no amount of retrying puts a define into a build. It reports `PluginMissing`,
  which `IsIntegrationError` covers.
- **`TikTokLoginResult` carries the raw material too** — `authCode`, `tiktokError`,
  `httpStatus` and `rawResponse`, so the wrapper is not a ceiling. `LoginResponse`
  is internal, so a field the backend adds was previously unreachable from a game
  until the SDK shipped again; `rawResponse` makes it readable today.
- **Typed login failures.** `TikTokLoginResult` carries a `TikTokLoginFailure`
  plus `IsRetryable` / `IsIntegrationError`, so the UI can answer the question it
  actually has — offer a retry, or tell a developer. A player who dismissed
  TikTok's sheet, an unreachable backend and a blank Sdk Key were previously one
  string, and `EnsureAuthenticated` collapsed all of them to "Not logged in".
- **`TikTokSDK.editorUseTikTokLogin`** — Editor-only toggle that runs TikTok's own
  login before the test login, so its mock panel appears and the signed-in /
  not-signed-in / failed branches can be exercised without a device build. Off by
  default; ignored outside the Editor. Without it the Editor could only ever
  produce a successful login, so no game could test the UI it draws for a failed one.
- **`TikTokPlatform`** — plugin lifecycle in one place: `EnsureReady` (idempotent,
  10s timeout, queues concurrent callers), `IsReady`, `IsPluginPresent`,
  `IsPluginInitialised`, `InitCode`, and `MarkReady()`.

  `IsPluginInitialised` detects an init the GAME performed, so a game with its own
  `TT.InitSDK` needs no code change: `EnsureReady` sees the plugin is already up
  and does not call it again. TTSDK publishes no init flag — `TT.s_ContainerEnv`
  is public but the `m_Inited` on it is internal — so this reads it by reflection,
  best effort, and answers false on a plugin version that moved it. False costs
  nothing: the SDK then initialises as it would have anyway.
  It also enables TikTok's Editor mocks, which are off by default and whose
  absence makes an Editor ad request return success having drawn nothing.
- **`TikTokAuth.AuthCodeProvider`** is now an OPTIONAL override for a custom auth
  flow rather than required wiring. Left null, `Login` calls `TT.Login` itself.
- **`TikTokSDK.RegisterRefundHandler(handler)`** — refunds were delivered only by
  casting the reward handler to `ITikTokRefundHandler`, which ruled out putting
  them on any other object.
- **`TikTokMissions.RegisteredTypes`** — build a mission UI from what is actually
  registered.
- **Integration Checklist reports both versions.** The HS SDK's version and how it
  was installed (local source, `.tgz`, registry — which decides whether editing the
  repo changes anything), and TikTok's plugin version with the TTSDK API version it
  ships. Neither was visible anywhere in the Editor, and TikTok's plugin is usually
  dropped into `Assets/Plugins`, where the Package Manager cannot see it either.
  It also names the project and shows `ttsdk.dll`'s date and size, because TikTok
  does not fill their version in consistently — a March drop declares `1.0.0` and a
  July one `1.1.5-Release`, both embedding the same 6.5.5 changelog, and the
  assembly itself is built as `0.0.0.0`. "Copy versions for a bug report" puts all
  of it, plus Unity, build target and defines, on the clipboard.

### Fixed
- **A broken SDK object could not be repaired.** Swapping the SDK between the
  source package and the DLL package leaves four components with missing scripts —
  a scene stores a script by guid, and a `.cs` file's guid is not the assembly's.
  `TikTokMissions` survives because it ships as source in both, which is why the
  Inspector shows four broken and one intact.

  The checklist then reported "no SDK object" (the component is gone) while
  `SetupSDK` reported "already exists" (the GameObject is not), and the button the
  checklist offered was the one that refused — a deadlock with no way out but
  deleting the object by hand and re-entering the credentials.

  `SetupSDK` now tops up whatever it finds: it strips components whose script is
  missing, adds back only what is absent, fixes the name and parent, and re-seeds
  the credentials from the last set this project used. The checklist detects the
  state, explains the cause, and offers **Repair SDK object**.

### Changed
- **`EnsureAuthenticated` is now a thin wrapper over `Login`.** Kept for existing
  games; new code should use `Login`, which says why it failed.
- **Missions report a refusal instead of returning silently.** `Execute` on an
  unregistered or already-running mission now fires `OnMissionResult` with
  `Failed` and a reason. A game that spins its button on `Execute` and stops on
  the result used to spin forever, which reads as a hung TikTok API rather than
  as a missing `Register()`.
- **Ad state resets on Play.** `TikTokAds` is static, so the config, cooldowns and
  rate-limit history survived a play-mode exit — a place could look to be on
  cooldown from an ad shown before you pressed Stop.
- **`ShowAd` with no id** now says so, and names `ShowAdOfType`, instead of
  "Invalid AdRequest".
- **A reward with nowhere to go is now an error, not silence.** Both delivery
  routes — `ITikTokRewardHandler` and the `OnPurchaseSuccess` /
  `OnPendingRewardRecovered` events — used `?.`, so a game that registered
  neither, or registered after logging in, had paid orders delivered to nothing
  while the backend marked them delivered. Purchases and login-time recovery now
  log loudly when both routes are absent.

### Samples
- **Ads and missions now have samples**, and login was rewritten around the new API:
  - **`SampleLoginHandler`** — rewritten. It was teaching the manual
    `TT.Login` → `LoginWithCode` dance, which is now the SDK's job; it shows
    `Login(result => …)` and what to draw for each failure instead.
  - **`SampleAdsHandler`** — place labels versus ad units, `ResolvePlace` to gate
    the button before offering it, and rewarding on `completed` rather than
    `success`. Covers 400 / 404 / 11004 and why an interstitial has to let the game
    continue on failure too.
  - **`SampleMissionsHandler`** — registering the missions a game offers, one result
    handler, and the claim guard, which is the game's and not the SDK's: TikTok
    confirms the task is done, never that you have already paid for it.

### QA harness
- **Rebuilt as a mock game.** Loading screen, home menu, missions, shop and ads —
  overlays only, no gameplay — each wired the way the integration guide says to
  wire it, so the order of calls around a game's own UI is what gets tested. The
  old flat tab list is still there as DEV. The ads screen has a section per entry
  point: by place label, with each label's waterfall and what it resolves to; by
  ad unit id; and a history with the rate limits. Every result shows the ad's id
  and type.
- **Fixed the unreadable UI on device.** Scale came from `Screen.dpi`, which the
  TikTok container reports as 0 or as the desktop's value; the fallback then
  divided physical pixels by 800 and produced IMGUI's untouched defaults, a few
  millimetres tall on a phone. It now scales off the screen's short edge.
- **The ads-only integration is testable.** `Skip Startup Login` on the harness
  starts without a session, the way a game that uses TikTok's own login does — the
  only way to reach the `/api/ads/config` recovery, since a login always brings the
  config with it. The ADS screen reports whether config is loaded and where it came
  from, with a button to fetch it explicitly; DEV ▸ FAIL adds "ad place before any
  login" and "LoadRemoteConfig".
- The harness registers its reward, refund and sync handlers and both missions at
  startup, as a game does. They were behind a button, so a pending reward
  recovered at login was delivered to nothing.

## [1.0.5] - 2026-08-19

### Added
- **Ads module (`TikTokAds`)** — rewarded and interstitial ads driven by server-side
  placement config. `ShowAdsRemote(label, cb)` resolves a place label through a
  remote waterfall; `ShowAd(request, cb)` targets an ad unit directly.
  `GetActivePlacements()`, `GetRateLimits()` and `RawIaaConfigJson` expose the
  resolved config, and `OnAdLogSent` / `OnInitCompleted` report activity.
- **`AdRequest.useRawJsBridge`** — selects the `.jslib` bridge over the `TTSDK`
  managed API for a given request.
- **Per-ad cooldowns** — remote config moved from a flat `waterfall` of ids to a
  list of `RemoteAdItem`, so a cooldown travels with the ad rather than the
  placement.

### Fixed
- **WebGL: ad callback delivery** — `SendMessage` is unreliable inside the Minigame
  container. The bridge now queues callbacks on `window.HSTikTokAdsCallbacks` and
  `Update()` drains them through `HS_TikTokPopAdsCallback` with a growable buffer.
  The SDK object is forced to the scene root and the JS-facing methods are marked
  `[Preserve]`, so neither reparenting nor IL2CPP stripping can break delivery.
- **WebGL: error codes** — the Minigame runtime reports `err.errorCode`; the bridge
  now reads it before falling back to `err.errCode`.
- **Ads: frequency cap** — `SmartAdTimeoutCheck` covers the case where TikTok
  silently swallows a `show()` blocked by its own frequency cap.
- **Missions were missing from the DLL package.** The mission scripts ship as
  source, but no Assembly Definition covered them, and Unity does not compile
  package scripts that no asmdef owns. `TikTokMissions`, `EntranceMission` and
  `ShortcutMission` therefore did not exist in any project installed from a
  `-dll.tgz`. The package now carries a Runtime asmdef.
- **Compiling without the TikTok plugin.** The mission scripts referenced
  `TTSDK.TT.*` unguarded, so the SDK failed to compile in any project that did
  not already have the TikTok Unity plugin. They now sit behind
  `TTSDK_MIX_ENGINE` like the ads module, and report success without it.

## [1.0.4] - 2026-05-21

### Fixed
- **Stability:** Added `15` second timeout (`req.timeout = 15;`) to all SDK HTTP requests to prevent indefinite hangs on poor networks.
- **WebGL:** Wrapped JavaScript SDK `pay` calls in `try/catch` blocks so synchronous browser exceptions don't permanently hang the Unity purchase state.
- **Auth:** Backend now properly stringifies `profile_data` so Unity's `JsonUtility` can correctly map it into the response string.

## [1.0.3] - 2026-05-21

### Added
- **`TikTokIAP.GetOrders(callback, status?)`** — public API for games to manually query player orders from the backend. Supports optional status filter (`PAID`, `REFUND_PENDING`, `REFUND_APPROVED`, etc.).
- **`TikTokOrder`** — new public model exposing order data (order_id, product_id, status, amount_beans, refund info, rewards). Includes helper properties: `IsRefunded`, `IsRefundPending`, `IsTestOrder`.
- **`SampleOrdersHandler.cs`** — sample showing manual order querying for all orders, refunded orders, purchase history, and pending refunds.
- **Backend `POST /orders`** — new player-facing endpoint for querying own orders with optional status filter. Scoped by `game_id`.

## [1.0.2] - 2026-05-20

### Fixed
- **Auth: Login response handling** — SDK now processes `pending_rewards` and `refund_orders` inline from the login response instead of dropping them. Eliminates redundant `POST /pending_rewards` HTTP call after login.
- **Auth: Refund delivery** — `refund_orders` from the login response are now delivered to the game via `OnRefundNotified` event and `ITikTokRewardHandler.OnRefundNotified()`. Previously these were silently lost.

### Added
- `OnRefundNotified` event on `TikTokIAP` — fired when the backend reports a refund.
- `ITikTokRefundHandler` — new **optional** interface for refund notifications. Games opt-in by implementing it alongside `ITikTokRewardHandler`. Games that don't implement it still work fine.
- `RefundOrder` model for refund data deserialization.
- `DeliverPendingRewards()` and `DeliverRefundOrders()` internal methods on `TikTokIAP` for inline delivery from login.

## [1.0.1] - 2026-05-19

### Fixed
- **IAP: HTTP error body parsing** — `CreateOrderRoutine` now reads the JSON response body on HTTP 4xx/5xx errors (e.g. 404 "Product not found or inactive") instead of only reporting the generic `req.error` string. `OnPurchaseFailed` now delivers the backend's specific error message.
- **Build: DLL compilation** — `build-dll.sh` now references the TikTok `ttsdk.dll` to resolve `TTSDK` namespace dependencies in Mission scripts.

## [1.0.0] - 2026-05-14

### Added
- Core SDK singleton (`TikTokSDK`) with Inspector-configurable backend URL, Game ID, and Test Mode.
- Authentication module (`TikTokAuth`) — login via TikTok auth code or Editor mock login.
- In-App Purchase module (`TikTokIAP`) — order creation, TikTok payment UI, backend polling, crash recovery.
- Cloud Sync module (`TikTokSync`) — offline-first background sync with configurable interval.
- Security module (`TikTokSecurity`) — AES-256 encryption with random IV, HMAC-SHA256 hash verification.
- Interface-based integration — `ITikTokSyncProvider` and `ITikTokRewardHandler` for zero-coupling with game code.
- Editor tools — one-click SDK setup, automatic HTTP dev settings.
- Assembly Definitions for compilation isolation.
- UPM package support (`package.json`).
- Sample integration code.
