# Changelog

All notable changes to the **HS TikTok MiniGame SDK** will be documented in this file.

## [1.0.0] - 2026-05-14

### Added
- Core SDK singleton (`TikTokSDK`) with Inspector-configurable backend URL, Game ID, and Test Mode.
- Authentication module (`TikTokAuth`) — login via TikTok auth code or Editor mock login.
- In-App Purchase module (`TikTokIAP`) — order creation, TikTok payment UI, backend polling, crash recovery.
- Cloud Sync module (`TikTokSync`) — offline-first background sync with configurable interval.
- Security module (`TikTokSecurity`) — AES-256 encryption with random IV, HMAC-SHA256 hash verification.
- Interface-based integration — `ITikTokSyncProvider` and `ITikTokRewardHandler` for zero-coupling with game code.
- Editor tools — one-click SDK setup, automatic HTTP dev settings.
- Assembly Definitions for compilation isolation.
- UPM package support (`package.json`).
- Sample integration code.
