mergeInto(LibraryManager.library, {
    HS_TikTokShowAd: function (adUnitIdPtr, typePtr, contextPtr) {
        var adUnitId = UTF8ToString(adUnitIdPtr);
        var type = UTF8ToString(typePtr);
        var context = UTF8ToString(contextPtr);
        
        var UNITY_TARGET = "HS_TikTokSDK";
        
        console.log("[HS.TikTokSDK] Requesting ad via JS: " + adUnitId + " of type " + type);
        
        var adCallback = {
            context: context,
            success: false,
            completed: false,
            error_code: 0,
            error_message: ""
        };

        function sendCallback(callbackObj) {
            window.HSTikTokAdsCallbacks = window.HSTikTokAdsCallbacks || [];
            window.HSTikTokAdsCallbacks.push(JSON.stringify(callbackObj));
        }

        if (typeof tt === 'undefined') {
            adCallback.error_message = "TikTok API not found";
            sendCallback(adCallback);
            return;
        }

        try {
            if (type.toLowerCase().includes("reward")) {
                var rewardedVideoAd = tt.createRewardedVideoAd({ adUnitId: adUnitId });
                
                rewardedVideoAd.onError(function(err) {
                    console.error("[HS.TikTokSDK] Rewarded ad error:", err);
                    adCallback.error_code = err.errorCode || err.errCode || 500;
                    adCallback.error_message = err.errMsg || "Unknown Error";
                    sendCallback(adCallback);
                });
                
                rewardedVideoAd.onClose(function(res) {
                    console.log("[HS.TikTokSDK] Rewarded ad closed:", res);
                    adCallback.success = true;
                    // res.isEnded is true if the user watched the entire ad
                    adCallback.completed = res && res.isEnded;
                    sendCallback(adCallback);
                });
                
                var showPromise = rewardedVideoAd.show();
                if (showPromise) {
                    showPromise.catch(function(err) {
                        console.error("[HS.TikTokSDK] Show failed:", err);
                        adCallback.error_code = err.errorCode || err.errCode || 500;
                        adCallback.error_message = err.errMsg || "Show Promise Rejected";
                        sendCallback(adCallback);
                    });
                }
                
            } else if (type.toLowerCase().includes("interstitial")) {
                var interstitialAd = tt.createInterstitialAd({ adUnitId: adUnitId });
                
                interstitialAd.onError(function(err) {
                    console.error("[HS.TikTokSDK] Interstitial ad error:", err);
                    adCallback.error_code = err.errorCode || err.errCode || 500;
                    adCallback.error_message = err.errMsg || "Unknown Error";
                    sendCallback(adCallback);
                });
                
                interstitialAd.onClose(function() {
                    console.log("[HS.TikTokSDK] Interstitial ad closed.");
                    adCallback.success = true;
                    adCallback.completed = true; // Interstitials are considered completed once closed
                    sendCallback(adCallback);
                });
                
                var showPromise = interstitialAd.show();
                if (showPromise) {
                    showPromise.catch(function(err) {
                        console.error("[HS.TikTokSDK] Show failed:", err);
                        adCallback.error_code = err.errorCode || err.errCode || 500;
                        adCallback.error_message = err.errMsg || "Show Promise Rejected";
                        sendCallback(adCallback);
                    });
                }
            } else {
                adCallback.error_message = "Unsupported ad type: " + type;
                sendCallback(adCallback);
            }
        } catch (e) {
            console.error("[HS.TikTokSDK] Exception calling TikTok Ad API:", e);
            adCallback.error_code = 500;
            adCallback.error_message = e.message || "Unknown JS Error";
            sendCallback(adCallback);
        }
    },

    HS_TikTokPopAdsCallback: function(bufferPtr, bufferSize) {
        if (!window.HSTikTokAdsCallbacks || window.HSTikTokAdsCallbacks.length === 0) return 0;
        var cb = window.HSTikTokAdsCallbacks[0];
        var bytes = lengthBytesUTF8(cb) + 1;
        if (bytes > bufferSize) return bytes; // Need more space
        window.HSTikTokAdsCallbacks.shift();
        stringToUTF8(cb, bufferPtr, bufferSize);
        return bytes;
    }
});
