namespace HS.TikTokSDK.Missions
{
    /// <summary>
    /// Shortcut Mission — shows native TikTok "Add Shortcut" dialog.
    /// 
    /// SDK handles:
    ///   - TT.AddShortcut() → native in-app dialog
    ///   - TT.GetShortcutMissionReward() → verify mission
    ///   - Reports Success or Failed
    ///
    /// Game handles:
    ///   - Once/daily claim checks
    ///   - Granting rewards
    ///   - UI feedback
    /// 
    /// The TTSDK_MIX_ENGINE guard is what lets the SDK compile in a project
    /// that does not have the TikTok Unity plugin installed — a blank project,
    /// or CI. Without the plugin the mission reports success the same way the
    /// Editor path does, so nothing downstream has to care.
    /// </summary>
    public class ShortcutMission : TikTokMissionBase
    {
        public override MissionType Type => MissionType.ShortcutMission;

        protected override void OnExecute()
        {
#if TTSDK_MIX_ENGINE
            if (IsWebGL)
            {
                TikTokSDK.Log($"[Missions] {Type}: Calling TT.AddShortcut()...");
                try
                {
                    TTSDK.TT.AddShortcut(
                        csCallback: (success) =>
                        {
                            TikTokSDK.Log($"[Missions] {Type}: TT.AddShortcut result: {success}");
                            if (success)
                                VerifyMissionReward();
                            else
                                CompleteFailed("User cancelled");
                        }
                    );
                }
                catch (System.Exception e)
                {
                    TikTokSDK.LogError($"[Missions] {Type}: Exception calling TT API: {e.Message}");
                    CompleteFailed(e.Message);
                }
            }
            else
#endif
            {
                TikTokSDK.Log($"[Missions] {Type}: no TikTok plugin here — simulating success.");
                CompleteSuccess();
            }
        }

        private void VerifyMissionReward()
        {
#if TTSDK_MIX_ENGINE
            if (IsWebGL)
            {
                TikTokSDK.Log($"[Missions] {Type}: Calling TT.GetShortcutMissionReward()...");
                try
                {
                    TTSDK.TT.GetShortcutMissionReward(new TTSDK.GetShortcutMissionRewardParam
                    {
                        Success = (result) =>
                        {
                            if (result.CanReceiveReward)
                            {
                                TikTokSDK.Log($"[Missions] {Type}: CanReceiveReward = true!");
                                CompleteSuccess();
                            }
                            else
                            {
                                TikTokSDK.Log($"[Missions] {Type}: CanReceiveReward = false.");
                                CompleteFailed("Mission not complete");
                            }
                        },
                        Fail = (error) =>
                        {
                            string errMsg = error?.ToString() ?? "Unknown error";
                            TikTokSDK.LogError($"[Missions] {Type}: GetShortcutMissionReward FAILED: {errMsg}");
                            CompleteFailed(errMsg);
                        }
                    });
                }
                catch (System.Exception e)
                {
                    TikTokSDK.LogError($"[Missions] {Type}: Exception verifying: {e.Message}");
                    CompleteFailed(e.Message);
                }
            }
            else
#endif
            {
                CompleteSuccess();
            }
        }
    }
}
