# Changelog

All notable changes to the **HS TikTok MiniGame SDK for Unity** (`com.hs.tiktok-sdk`)
are documented in this file. The HTML5 build has its own changelog in `js/CHANGELOG.md`.

## [1.0.7] - 2026-09-24

### Added
- **Paid orders are confirmed by the client, after the game has them.** Login,
  purchase polling and `CheckPendingRewards` send `client_ack: true`; the
  backend then leaves orders unmarked (`ack_required`). The SDK hands each order
  to the game, records its id locally (PlayerPrefs, per game and player) and
  confirms all of them in one call to `/orders/mark_delivered`. An id leaves
  that list only once the backend has answered for it. Before, the backend
  marked orders delivered before the response left, so a dropped connection, a
  killed app or a throwing handler lost a paid order for good. Now an order the
  game did not take comes back at the next login, and one it took whose
  confirmation was lost is confirmed without being granted twice. Needs the
  backend of 2026-09-24; against an older one (`ack_required: false`) the SDK
  behaves exactly as before.
- **`TikTokIAP.OnOrderRewardsDelivered(TikTokPaidOrder)`** — every paid order
  with its `order_id`, fired alongside the existing callbacks. Manual-refund
  games need the id for `MarkOrderDelivered`, and never received it.
- **`X-SDK-Version`** on every request (`TikTokSDK.SdkVersion`), for backend
  logs. `pack-dll.sh` refuses to pack when it disagrees with package.json.
- `TikTokAuth.IsLoggingIn`; `LoginWithCode` and `EditorMockLogin` take an
  optional result callback.
- **`CheckPendingRewards(Action<int> onComplete)`** — optional; answers once with
  the number of orders delivered (0 = nothing pending, -1 = the check failed).
  No event fires for zero, so a loading screen could only wait out a timer.
- **`TikTokIAP.RefundMode`** — "auto" or "manual", from the login response, so
  a game knows whether it must call `MarkOrderDelivered` itself.

### Fixed
- **The DLL package works in Editor Play mode with TikTok plugin 1.1.x.** That
  plugin ships its API as `ttsdk.dll` (WebGL only) and `ttsdk-editor.dll`
  (Editor only); the precompiled SDK names `ttsdk`, which is not loaded in the
  Editor, so the first call into TikTok threw `TypeLoadException` — login, ads
  and IAP failed in Play mode while device builds worked. Also true of 1.0.6.
  The package now ships an Editor-only `Editor/TTSDKFacade/ttsdk.dll`: an
  assembly named `ttsdk` holding only type forwards to `ttsdk-editor`. Builds
  exclude it and bind to TikTok's real `ttsdk.dll`. The source package never
  had this. The facade only switches on with TikTok plugin 1.1.x: an Editor
  script sets `HS_TTSDK_EDITOR_ASSEMBLY` when `ttsdk-editor.dll` is present and
  removes it when not. TikTok plugin 1.0.x ships one `ttsdk.dll` that is active
  in the Editor already, so there the facade stays off and nothing changes.
- **One login at a time.** Until the first login finished, every
  `EnsureAuthenticated` caller (Buy, Sync, CheckPendingRewards…) started its own
  `TT.Login` and backend exchange, each session overwriting the last. Callers
  now join the running login and all get its one result, exactly once each.
- **`TT.Login` times out after 15 s** instead of leaving the game on its splash
  screen when TikTok never answers. A late answer is ignored.
- **Re-login after a 401 during a purchase works on device.** It called
  `LoginWithCode(null)`, which the backend refuses without a code, and leaked
  two event handlers per attempt. It now uses `Login()`.
- **A second tap on Buy during login no longer opens a second order.** It now
  gets `OnPurchaseFailed("A purchase is already in progress.")`.
- **A purchase recovered by login while its poll ran is not granted twice**
  (`already_delivered`); the purchase ends with `OnPurchaseFailed("This purchase
  was already delivered.")`.
- **Game callbacks are isolated.** A throw in `OnLoginSuccess`, a login result
  callback, a reward/refund handler or an event no longer stops the steps after
  it — the other callers, the other orders, the pending-reward delivery.
- **An ad callback always reaches the game.** The managed ad path built its
  result JSON by string interpolation, so a TikTok error message holding `"` or
  `\` failed to parse and `onComplete` never fired. Results are now serialised
  with `JsonUtility`. A payload that still cannot be read fails its call with
  `error_code 500` and the reason, instead of being dropped. A throw from
  `TT.Create*Ad`, or a missing `TikTokSDK` object, now reaches the game as an
  error rather than escaping or leaving the call pending. An exception inside
  the game's own `onComplete` is logged as such, no longer as a parse error.
- **Login and cloud sync cannot hang on a bad response.** A non-JSON body (a
  proxy's HTML page) threw inside the coroutine: login never answered, and sync
  left `IsSyncing` true for the rest of the session. Both now fail with the
  HTTP status and the start of the body. A 301 to a URL the SDK rejects no
  longer retries forever, and a login request that cannot be built reports
  `NotConfigured`.
- **Purchase polling and auto-sync run on real time.** Both waited with
  `WaitForSeconds`, so a game paused with `Time.timeScale = 0` froze them: the
  purchase never confirmed, the 60 s limit never fired, and every later
  `BuyProduct` was refused as "already processing". A purchase now always ends
  in exactly one `OnPurchaseSuccess` or `OnPurchaseFailed`; the failure names
  the last problem (HTTP status, unreadable body, request not built). A throw in
  the game's `OnPurchaseSuccess` no longer stops `OnPurchaseRewardsGranted`.
- **iOS: a finished rewarded ad no longer fails with 11004.** The ad result now
  comes from TikTok only — `OnError` or `OnClose(isEnded)` — and reaches the game
  unchanged. `SmartAdTimeoutCheck` is removed. It guessed a swallowed show failure
  when 2.5 s passed with no focus/pause event, but on iOS the ad covers the screen
  without either, and Unity runs no frames until it closes: the first frame after
  every ad longer than 2.5 s fired a synthetic `11004 "Timeout: Rate limit
  frequency cap hit"`, and the real `OnClose(isEnded: true)` a few ms later was
  dropped, so the player got no reward. Applies to `useRawJsBridge = false` (the
  `ShowAdsRemote` path), rewarded and interstitial. If TikTok ever blocks a show
  without calling `OnError`, the callback now does not fire, rather than firing
  a wrong one.

## [1.0.6] - 2026-08-21

### Added
- **Ads: read the remote config instead of re-parsing it.** `ResolvePlace(label)`
  answers what `ShowAdsRemote` would show right now — the chosen unit, or the
  reason there is none — and walks the whole waterfall with a per-candidate skip
  reason, without showing anything or starting a cooldown. Alongside it:
  `GetPlaceLabels()`, `GetPlacement(label)`, `GetCooldownRemaining(label, adId)`,
  `GetActivePlacementsOfType(type)`, `GetAdLogs()` and the parsed `Config`. Games
  were parsing `RawIaaConfigJson` themselves against a schema they do not own.
- **`AdResult` now names the ad.** `ad_id`, `ad_type`, `place_label` and `context`
  are filled on every callback, failures included. A game calling `ShowAdsRemote`
  never chose the unit, so without these it could not log which one paid, tell two
  units at one place apart, or put an id in a support ticket.
- **Ads no longer die with login.** `iaa_config` arrived only inside the login
  response, so a game that used TikTok's own login, or none at all, had an empty
  waterfall and got `404` for every place — though showing an ad needs no session
  and never touches our backend. `ShowAdsRemote` now silently fetches the config
  once from `POST /api/ads/config` when none has arrived, and reports `503` if
  that fetch fails instead of blaming the place label. `LoadRemoteConfig()` does
  it up front for ads-only games, and `IsConfigLoaded` reports the state.
- **`TikTokAds.ShowAdOfType(type, context, cb)`** — shows the first active unit of a
  type. `ShowAd` requires a unit id, so a request carrying only `type` was rejected
  with no supported alternative.
- **`TikTokAuth.Login(onResult)` — the SDK now owns the whole login.** One call
  initialises TikTok's plugin, obtains an auth code, exchanges it, and reports a
  single result. Games no longer call `TT.InitSDK` or `TT.Login` at all.

  The old split was justified as "the plugin belongs to the game", but the SDK
  already calls `TT.CreateRewardedVideoAd`, `TT.AddShortcut` and
  `TT.StartEntranceMission` — login was the one place left where it asked the game
  to make the call for it. Not a principle, an inconsistency, and one every
  partner rediscovered through a login that worked in the Editor and failed on a
  phone.
- **A missing plugin is now its own login failure.** In a TikTok build without
  `TTSDK_MIX_ENGINE`, `Login` reported `TikTokRejected` — flagged retryable, though
  no amount of retrying puts a define into a build. It reports `PluginMissing`,
  which `IsIntegrationError` covers.
- **`TikTokLoginResult` carries the raw material too** — `authCode`, `tiktokError`,
  `httpStatus` and `rawResponse`, so the wrapper is not a ceiling. `LoginResponse`
  is internal, so a field the backend adds was previously unreachable from a game
  until the SDK shipped again; `rawResponse` makes it readable today.
- **Typed login failures.** `TikTokLoginResult` carries a `TikTokLoginFailure`
  plus `IsRetryable` / `IsIntegrationError`, so the UI can answer the question it
  actually has — offer a retry, or tell a developer. A player who dismissed
  TikTok's sheet, an unreachable backend and a blank Sdk Key were previously one
  string, and `EnsureAuthenticated` collapsed all of them to "Not logged in".
- **`TikTokSDK.editorUseTikTokLogin`** — Editor-only toggle that runs TikTok's own
  login before the test login, so its mock panel appears and the signed-in /
  not-signed-in / failed branches can be exercised without a device build. Off by
  default; ignored outside the Editor. Without it the Editor could only ever
  produce a successful login, so no game could test the UI it draws for a failed one.
- **`TikTokPlatform`** — plugin lifecycle in one place: `EnsureReady` (idempotent,
  10s timeout, queues concurrent callers), `IsReady`, `IsPluginPresent`,
  `IsPluginInitialised`, `InitCode`, and `MarkReady()`.

  `IsPluginInitialised` detects an init the GAME performed, so a game with its own
  `TT.InitSDK` needs no code change: `EnsureReady` sees the plugin is already up
  and does not call it again. TTSDK publishes no init flag — `TT.s_ContainerEnv`
  is public but the `m_Inited` on it is internal — so this reads it by reflection,
  best effort, and answers false on a plugin version that moved it. False costs
  nothing: the SDK then initialises as it would have anyway.
  It also enables TikTok's Editor mocks, which are off by default and whose
  absence makes an Editor ad request return success having drawn nothing.
- **`TikTokAuth.AuthCodeProvider`** is now an OPTIONAL override for a custom auth
  flow rather than required wiring. Left null, `Login` calls `TT.Login` itself.
- **`TikTokSDK.RegisterRefundHandler(handler)`** — refunds were delivered only by
  casting the reward handler to `ITikTokRefundHandler`, which ruled out putting
  them on any other object.
- **`TikTokMissions.RegisteredTypes`** — build a mission UI from what is actually
  registered.
- **Integration Checklist reports both versions.** The HS SDK's version and how it
  was installed (local source, `.tgz`, registry — which decides whether editing the
  repo changes anything), and TikTok's plugin version with the TTSDK API version it
  ships. Neither was visible anywhere in the Editor, and TikTok's plugin is usually
  dropped into `Assets/Plugins`, where the Package Manager cannot see it either.
  It also names the project and shows `ttsdk.dll`'s date and size, because TikTok
  does not fill their version in consistently — a March drop declares `1.0.0` and a
  July one `1.1.5-Release`, both embedding the same 6.5.5 changelog, and the
  assembly itself is built as `0.0.0.0`. "Copy versions for a bug report" puts all
  of it, plus Unity, build target and defines, on the clipboard.

### Fixed
- **A broken SDK object could not be repaired.** Swapping the SDK between the
  source package and the DLL package leaves four components with missing scripts —
  a scene stores a script by guid, and a `.cs` file's guid is not the assembly's.
  `TikTokMissions` survives because it ships as source in both, which is why the
  Inspector shows four broken and one intact.

  The checklist then reported "no SDK object" (the component is gone) while
  `SetupSDK` reported "already exists" (the GameObject is not), and the button the
  checklist offered was the one that refused — a deadlock with no way out but
  deleting the object by hand and re-entering the credentials.

  `SetupSDK` now tops up whatever it finds: it strips components whose script is
  missing, adds back only what is absent, fixes the name and parent, and re-seeds
  the credentials from the last set this project used. The checklist detects the
  state, explains the cause, and offers **Repair SDK object**.

### Changed
- **`EnsureAuthenticated` is now a thin wrapper over `Login`.** Kept for existing
  games; new code should use `Login`, which says why it failed.
- **Missions report a refusal instead of returning silently.** `Execute` on an
  unregistered or already-running mission now fires `OnMissionResult` with
  `Failed` and a reason. A game that spins its button on `Execute` and stops on
  the result used to spin forever, which reads as a hung TikTok API rather than
  as a missing `Register()`.
- **Ad state resets on Play.** `TikTokAds` is static, so the config, cooldowns and
  rate-limit history survived a play-mode exit — a place could look to be on
  cooldown from an ad shown before you pressed Stop.
- **`ShowAd` with no id** now says so, and names `ShowAdOfType`, instead of
  "Invalid AdRequest".
- **A reward with nowhere to go is now an error, not silence.** Both delivery
  routes — `ITikTokRewardHandler` and the `OnPurchaseSuccess` /
  `OnPendingRewardRecovered` events — used `?.`, so a game that registered
  neither, or registered after logging in, had paid orders delivered to nothing
  while the backend marked them delivered. Purchases and login-time recovery now
  log loudly when both routes are absent.

### Samples
- **Ads and missions now have samples**, and login was rewritten around the new API:
  - **`SampleLoginHandler`** — rewritten. It was teaching the manual
    `TT.Login` → `LoginWithCode` dance, which is now the SDK's job; it shows
    `Login(result => …)` and what to draw for each failure instead.
  - **`SampleAdsHandler`** — place labels versus ad units, `ResolvePlace` to gate
    the button before offering it, and rewarding on `completed` rather than
    `success`. Covers 400 / 404 / 11004 and why an interstitial has to let the game
    continue on failure too.
  - **`SampleMissionsHandler`** — registering the missions a game offers, one result
    handler, and the claim guard, which is the game's and not the SDK's: TikTok
    confirms the task is done, never that you have already paid for it.

### QA harness
- **Rebuilt as a mock game.** Loading screen, home menu, missions, shop and ads —
  overlays only, no gameplay — each wired the way the integration guide says to
  wire it, so the order of calls around a game's own UI is what gets tested. The
  old flat tab list is still there as DEV. The ads screen has a section per entry
  point: by place label, with each label's waterfall and what it resolves to; by
  ad unit id; and a history with the rate limits. Every result shows the ad's id
  and type.
- **Fixed the unreadable UI on device.** Scale came from `Screen.dpi`, which the
  TikTok container reports as 0 or as the desktop's value; the fallback then
  divided physical pixels by 800 and produced IMGUI's untouched defaults, a few
  millimetres tall on a phone. It now scales off the screen's short edge.
- **The ads-only integration is testable.** `Skip Startup Login` on the harness
  starts without a session, the way a game that uses TikTok's own login does — the
  only way to reach the `/api/ads/config` recovery, since a login always brings the
  config with it. The ADS screen reports whether config is loaded and where it came
  from, with a button to fetch it explicitly; DEV ▸ FAIL adds "ad place before any
  login" and "LoadRemoteConfig".
- The harness registers its reward, refund and sync handlers and both missions at
  startup, as a game does. They were behind a button, so a pending reward
  recovered at login was delivered to nothing.

## [1.0.5] - 2026-08-19

### Added
- **Ads module (`TikTokAds`)** — rewarded and interstitial ads driven by server-side
  placement config. `ShowAdsRemote(label, cb)` resolves a place label through a
  remote waterfall; `ShowAd(request, cb)` targets an ad unit directly.
  `GetActivePlacements()`, `GetRateLimits()` and `RawIaaConfigJson` expose the
  resolved config, and `OnAdLogSent` / `OnInitCompleted` report activity.
- **`AdRequest.useRawJsBridge`** — selects the `.jslib` bridge over the `TTSDK`
  managed API for a given request.
- **Per-ad cooldowns** — remote config moved from a flat `waterfall` of ids to a
  list of `RemoteAdItem`, so a cooldown travels with the ad rather than the
  placement.

### Fixed
- **WebGL: ad callback delivery** — `SendMessage` is unreliable inside the Minigame
  container. The bridge now queues callbacks on `window.HSTikTokAdsCallbacks` and
  `Update()` drains them through `HS_TikTokPopAdsCallback` with a growable buffer.
  The SDK object is forced to the scene root and the JS-facing methods are marked
  `[Preserve]`, so neither reparenting nor IL2CPP stripping can break delivery.
- **WebGL: error codes** — the Minigame runtime reports `err.errorCode`; the bridge
  now reads it before falling back to `err.errCode`.
- **Ads: frequency cap** — `SmartAdTimeoutCheck` covers the case where TikTok
  silently swallows a `show()` blocked by its own frequency cap.
- **Missions were missing from the DLL package.** The mission scripts ship as
  source, but no Assembly Definition covered them, and Unity does not compile
  package scripts that no asmdef owns. `TikTokMissions`, `EntranceMission` and
  `ShortcutMission` therefore did not exist in any project installed from a
  `-dll.tgz`. The package now carries a Runtime asmdef.
- **Compiling without the TikTok plugin.** The mission scripts referenced
  `TTSDK.TT.*` unguarded, so the SDK failed to compile in any project that did
  not already have the TikTok Unity plugin. They now sit behind
  `TTSDK_MIX_ENGINE` like the ads module, and report success without it.

## [1.0.4] - 2026-05-21

### Fixed
- **Stability:** Added `15` second timeout (`req.timeout = 15;`) to all SDK HTTP requests to prevent indefinite hangs on poor networks.
- **WebGL:** Wrapped JavaScript SDK `pay` calls in `try/catch` blocks so synchronous browser exceptions don't permanently hang the Unity purchase state.
- **Auth:** Backend now properly stringifies `profile_data` so Unity's `JsonUtility` can correctly map it into the response string.

## [1.0.3] - 2026-05-21

### Added
- **`TikTokIAP.GetOrders(callback, status?)`** — public API for games to manually query player orders from the backend. Supports optional status filter (`PAID`, `REFUND_PENDING`, `REFUND_APPROVED`, etc.).
- **`TikTokOrder`** — new public model exposing order data (order_id, product_id, status, amount_beans, refund info, rewards). Includes helper properties: `IsRefunded`, `IsRefundPending`, `IsTestOrder`.
- **`SampleOrdersHandler.cs`** — sample showing manual order querying for all orders, refunded orders, purchase history, and pending refunds.
- **Backend `POST /orders`** — new player-facing endpoint for querying own orders with optional status filter. Scoped by `game_id`.

## [1.0.2] - 2026-05-20

### Fixed
- **Auth: Login response handling** — SDK now processes `pending_rewards` and `refund_orders` inline from the login response instead of dropping them. Eliminates redundant `POST /pending_rewards` HTTP call after login.
- **Auth: Refund delivery** — `refund_orders` from the login response are now delivered to the game via `OnRefundNotified` event and `ITikTokRewardHandler.OnRefundNotified()`. Previously these were silently lost.

### Added
- `OnRefundNotified` event on `TikTokIAP` — fired when the backend reports a refund.
- `ITikTokRefundHandler` — new **optional** interface for refund notifications. Games opt-in by implementing it alongside `ITikTokRewardHandler`. Games that don't implement it still work fine.
- `RefundOrder` model for refund data deserialization.
- `DeliverPendingRewards()` and `DeliverRefundOrders()` internal methods on `TikTokIAP` for inline delivery from login.

## [1.0.1] - 2026-05-19

### Fixed
- **IAP: HTTP error body parsing** — `CreateOrderRoutine` now reads the JSON response body on HTTP 4xx/5xx errors (e.g. 404 "Product not found or inactive") instead of only reporting the generic `req.error` string. `OnPurchaseFailed` now delivers the backend's specific error message.
- **Build: DLL compilation** — `build-dll.sh` now references the TikTok `ttsdk.dll` to resolve `TTSDK` namespace dependencies in Mission scripts.

## [1.0.0] - 2026-05-14

### Added
- Core SDK singleton (`TikTokSDK`) with Inspector-configurable backend URL, Game ID, and Test Mode.
- Authentication module (`TikTokAuth`) — login via TikTok auth code or Editor mock login.
- In-App Purchase module (`TikTokIAP`) — order creation, TikTok payment UI, backend polling, crash recovery.
- Cloud Sync module (`TikTokSync`) — offline-first background sync with configurable interval.
- Security module (`TikTokSecurity`) — AES-256 encryption with random IV, HMAC-SHA256 hash verification.
- Interface-based integration — `ITikTokSyncProvider` and `ITikTokRewardHandler` for zero-coupling with game code.
- Editor tools — one-click SDK setup, automatic HTTP dev settings.
- Assembly Definitions for compilation isolation.
- UPM package support (`package.json`).
- Sample integration code.
