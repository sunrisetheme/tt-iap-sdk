# HS TikTok MiniGame SDK — Integration Guide (v1.0.7)

## Requirements

- Unity 2020+
- TikTok MiniGame Unity Plugin (with `TTSDK_MIX_ENGINE` scripting define).
  Any recent drop works — the SDK relies only on the plugin's stable core APIs
  (init, login, ads, missions, Editor mock), and the checklist verifies
  presence, not a version.

## Installation

**Package Manager → + → Add package from tarball...**
Select the `.tgz` file provided by the SDK distributor.

---

## 1. Setup the SDK in your Scene

**Menu:** `IAP TikTok Setup > Integration Checklist`, then press **Setup SDK in Scene**.

The checklist is the only entry point: it does this step and then checks the three
after it, which a bare menu command could not.

This creates a persistent `HS_TikTokSDK` GameObject with all required components:
- `TikTokSDK` — Core config & session
- `TikTokAuth` — Login
- `TikTokIAP` — In-App Purchases
- `TikTokSync` — Cloud Save (optional)

## 2. Configure in Inspector

Select the `HS_TikTokSDK` GameObject and set:

| Field | Description |
|-------|-------------|
| **Game ID** | Your TikTok App ID (numeric, from TikTok Developer Portal) |
| **SDK Key** | Your SDK key (starts with `sk_live_` or `sk_test_`, from HS Developer Portal) |
| **Enable Debug Logs** | Toggle SDK console logging (disable for production) |

> **Note:** Test mode is auto-detected at runtime. Unity Editor and non-WebGL platforms run in test mode. WebGL TikTok builds run in production mode automatically.

---

## 3. Login

One call. It initialises TikTok's plugin if needed, obtains an auth code,
exchanges it with the backend, and reports a single typed result.

```csharp
using HS.TikTokSDK.Auth;

TikTokAuth.Instance.Login(result =>
{
    if (result.success)
    {
        Debug.Log($"Signed in as {result.openId}");
        return;
    }

    if (result.IsIntegrationError)      // a developer must fix this
        Debug.LogError(result.message); //   never show a retry button
    else if (result.IsRetryable)        // network, TikTok, or the player said no
        ShowRetryButton();
});
```

In test mode — anything that is not a TikTok WebGL build — it skips TikTok
entirely and logs in with a device-derived test id, so the same call works in
the Editor.

You do **not** call `TT.InitSDK` or `TT.Login` yourself. The SDK already drives
TikTok's plugin for ads and missions; login is no different.

### Why the login failed

`result.failure` is a `TikTokLoginFailure`:

| value | meaning | offer retry? |
|---|---|---|
| `NotConfigured` | Game Id / Sdk Key blank on HS_TikTokSDK | no — fix the build |
| `SdkMissing` | TikTokSDK not in the scene | no — fix the build |
| `PluginMissing` | built without `TTSDK_MIX_ENGINE` | no — fix the build |
| `PluginInitFailed` | `TT.InitSDK` failed or never answered | yes |
| `UserCancelled` | the player dismissed TikTok's sheet | yes |
| `TikTokRejected` | `TT.Login` failed | yes |
| `BackendRejected` | the backend refused — bad code, unknown game | rarely |
| `NetworkError` | the backend could not be reached | yes |

`IsIntegrationError` and `IsRetryable` group these, so most games never switch
on the enum.

### Testing the failure paths in the Editor

By default the Editor never calls TikTok: `IsTestMode` is true off a TikTok
build, so `Login()` goes straight to the backend with a test id. Convenient, and
it means the only outcome you can reach is success — the UI your game draws for
a cancelled or rejected login cannot be exercised without a device build.

Tick **Editor Use TikTok Login** on the `HS_TikTokSDK` object to run TikTok's own
login first. Its Editor mock then appears with three choices, which map onto:

| mock choice | `result.failure` |
|---|---|
| `Login-success-登录` | none — success |
| `Login-success-未登录` | `UserCancelled` if no code comes back, otherwise success |
| `Login-失败-1` | `TikTokRejected` (`result.tiktokError` has TikTok's own words) |

The code TikTok returns is discarded — the backend still answers a test login.
What the detour buys is the verdict, and the branch your game takes because of
it. The flag is ignored outside the Editor, so it cannot change a build.

### When the wrapper is not enough

`TikTokLoginResult` also carries what the SDK itself worked from, so a detail it
does not model is still reachable:

| field | is |
|---|---|
| `authCode` | the code TikTok returned, before it was exchanged (empty in test mode) |
| `tiktokError` | `TT.Login`'s own error string, unedited |
| `httpStatus` | HTTP status from `/api/login`; `0` means it was never reached |
| `rawResponse` | the exact response body from `/api/login` |

`rawResponse` matters most: the SDK's `LoginResponse` type is internal, so a
field the backend adds is invisible to your game until the SDK ships a new
version. Read it yourself instead:

```csharp
[Serializable] class MyExtras { public string tier; public int streak; }

TikTokAuth.Instance.Login(result =>
{
    var extras = JsonUtility.FromJson<MyExtras>(result.rawResponse);
    if (extras != null && extras.tier == "vip") UnlockVipUi();
});
```

`rawResponse` contains the session token — do not forward it to a crash or
analytics service.

### Reading the login

The result says whether you are in. The **event** carries what came back:

```csharp
TikTokAuth.Instance.OnLoginSuccess += (string profileJson, long serverTimestamp) =>
{
    // profileJson is the player's cloud save — empty on a first login.
    // serverTimestamp is when the server last saw it.
};
```

After a success `TikTokSDK.Instance.IsAuthenticated` is true, and
`SessionToken` / `OpenId` are populated. The SDK has also applied server config,
initialised the ad module with this game's remote config, and delivered any
pending rewards and refunds.

### If your game already initialises the plugin

Nothing to do. `Login()` checks whether TikTok's plugin already reports itself
initialised and skips `TT.InitSDK` if so — calling it twice is not documented as
safe, so it is not called twice.

That check reads a flag TTSDK does not publish, so it is best effort. If your
plugin version hides it, or your own init is still in flight when the first
`Login()` lands, say so explicitly instead:

```csharp
TikTokPlatform.MarkReady();
```

| member | answers |
|---|---|
| `TikTokPlatform.IsPluginPresent` | was this built with `TTSDK_MIX_ENGINE` at all |
| `TikTokPlatform.IsPluginInitialised` | does TikTok's plugin report itself initialised, by anyone |
| `TikTokPlatform.IsReady` | has the SDK finished its own readiness step |
| `TikTokPlatform.InitCode` | what `TT.InitSDK` returned — 0 is success |

### Custom auth code flow (rare)

To supply the code yourself instead of letting the SDK call `TT.Login`:

```csharp
TikTokAuth.Instance.AuthCodeProvider = (onCode, onError) =>
    TT.Login(successCallback: code => onCode(code),
             failedCallback:  err  => onError(err));
```

Pass lambdas, not the callbacks themselves — `TT.Login` declares its own
delegate types and an `Action<string>` will not convert to one.

---

## 4. In-App Purchases

### Buy a Product

```csharp
using HS.TikTokSDK.IAP;

TikTokIAP.Instance.BuyProduct("1"); // product ID from your backend
```

### Product Config

Products are configured on the backend. The SDK only needs the **product ID** to initiate a purchase. The backend handles pricing and reward delivery.

Each product on the backend requires:

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique product ID (passed to `BuyProduct()`) |
| `beans_cost` | int | Price in TikTok Beans |
| `rewards` | array | List of rewards returned after payment confirmation |

Example backend product config:

```json
[
  { "id": "1", "beans_cost": 10, "rewards": [{ "type": "hints", "amount": 3 }] },
  { "id": "2", "beans_cost": 50, "rewards": [{ "type": "no_ads", "amount": 1 }] }
]
```

### TikTokReward Model

The SDK returns `TikTokReward` objects after a successful purchase:

```csharp
public class TikTokReward
{
    public string type;   // "hints", "no_ads", "gold", etc.
    public int amount;     // For countable rewards (3 hints, 100 gold)
    public bool value;     // For boolean flags (ads_removed = true)
}
```

| Reward Type | `amount` | `value` | Use Case |
|-------------|----------|---------|----------|
| `"hints"` | Count to add | — | `player.hints += reward.amount` |
| `"no_ads"` | — | `true` | `player.adsRemoved = true` |
| `"gold"` | Count to add | — | `player.gold += reward.amount` |

### Handle Purchase Events

```csharp
using HS.TikTokSDK;
using HS.TikTokSDK.IAP;

// Purchase confirmed
TikTokIAP.Instance.OnPurchaseSuccess += (string productId, List<TikTokReward> rewards) =>
{
    foreach (var reward in rewards)
    {
        Debug.Log($"Reward: {reward.type} x{reward.amount}");
        // Grant rewards to player
    }
};

// Purchase failed or canceled
TikTokIAP.Instance.OnPurchaseFailed += (string error) =>
{
    Debug.LogWarning($"Purchase failed: {error}");
};

// Crash recovery — undelivered rewards from previous sessions
TikTokIAP.Instance.OnPendingRewardRecovered += (string productId, List<TikTokReward> rewards) =>
{
    // Handle the same as OnPurchaseSuccess
};
```

### Using ITikTokRewardHandler (Recommended)

Instead of subscribing to events, implement the interface for cleaner code:

```csharp
using HS.TikTokSDK;
using System.Collections.Generic;

public class MyShopController : MonoBehaviour, ITikTokRewardHandler
{
    void Start()
    {
        TikTokSDK.Instance.RegisterRewardHandler(this);
    }

    public void OnPurchaseRewardsGranted(string productId, List<TikTokReward> rewards)
    {
        foreach (var r in rewards)
        {
            if (r.type == "hints") AddHints(r.amount);
            if (r.type == "ads_removed") RemoveAds();
        }
    }

    public void OnPendingRewardsRecovered(string productId, List<TikTokReward> rewards)
    {
        // Same handling as a normal purchase
        OnPurchaseRewardsGranted(productId, rewards);
    }
}
```

---

## 5. Cloud Sync (Optional)

Implement `ITikTokSyncProvider` to enable automatic cloud saves:

```csharp
using HS.TikTokSDK;

public class MySaveManager : MonoBehaviour, ITikTokSyncProvider
{
    private MyPlayerData _data;

    public bool IsDirtyForCloud { get; set; }

    public string SerializeForCloud()
    {
        // Return your save data as JSON
        return JsonUtility.ToJson(_data);
    }

    public void OnCloudSyncSuccess(long serverTimestamp)
    {
        // Save the server timestamp locally (do NOT set IsDirtyForCloud here)
        _data.lastUpdated = serverTimestamp;
        SaveLocally();
    }

    public void OnCloudDataReceived(string profileJson, long serverTimestamp)
    {
        // Server has newer data — overwrite local save
        _data = JsonUtility.FromJson<MyPlayerData>(profileJson);
        _data.lastUpdated = serverTimestamp;
        SaveLocally();
    }

    void Start()
    {
        TikTokSDK.Instance.RegisterSyncProvider(this);
    }

    // Call this whenever player data changes
    public void OnDataChanged()
    {
        IsDirtyForCloud = true;
        SaveLocally();
    }
}
```

### How Sync Works

- The SDK **auto-syncs** every 10 seconds when `IsDirtyForCloud` is `true`
- You can trigger a **manual sync** anytime:

```csharp
using HS.TikTokSDK.Sync;

TikTokSync.Instance.SyncNow(success =>
{
    Debug.Log(success ? "Synced!" : "Sync skipped or failed");
});
```

---

## 6. Refund Handling

When a player gets a refund through TikTok, the **backend handles everything** —
it deducts the rewards from `profile_data` and marks the order. The client
receives a notification for display purposes; there is nothing to reverse.

### What the client receives

On login, the response includes `refund_orders` (empty array when none):

```json
{
  "refund_orders": [
    {
      "order_id": 42,
      "product_id": 1,
      "name": "15 Hints",
      "refund_amount": 100,
      "refund_source": "tiktok_webhook",
      "rewards": [{ "type": "hints", "amount": 15 }]
    }
  ]
}
```

`refund_source` is `"tiktok_webhook"` or `"admin_manual"`. The `profile_data` in
the same login response **already reflects the deduction**.

### Getting notified

Either subscribe to the event:

```csharp
TikTokIAP.Instance.OnRefundNotified += (string productId, List<TikTokReward> revoked) =>
{
    // Backend already deducted — update the UI, show a notice.
    RefreshBalanceDisplay();
};
```

or implement the optional interface — on your reward handler, or on any other
object via `RegisterRefundHandler`:

```csharp
public class MyShopController : MonoBehaviour, ITikTokRewardHandler, ITikTokRefundHandler
{
    void Start()
    {
        TikTokSDK.Instance.RegisterRewardHandler(this);
        // ITikTokRefundHandler on the reward handler is picked up automatically.
        // On a different object: TikTokSDK.Instance.RegisterRefundHandler(that);
    }

    public void OnRefundNotified(string productId, List<TikTokReward> revokedRewards)
    {
        ShowPopup($"A purchase was refunded. Your balance has been updated.");
    }

    // ... OnPurchaseRewardsGranted / OnPendingRewardsRecovered as in section 4
}
```

With neither in place the refund is logged and lost — the SDK warns loudly when
that happens.

### Fallback: manual check mid-session

Refunds deliver automatically on login. For a session that stays open long
enough to miss one:

```csharp
TikTokIAP.Instance.CheckRefunds();   // any results arrive via OnRefundNotified
```

### Order status flow

| Status | Meaning |
|--------|---------|
| `REFUND_PENDING` | TikTok webhook received, awaiting approval |
| `REFUND_APPROVED` | Rewards deducted, waiting for client delivery |
| `REFUNDED` | Delivered to client — final state |

### Refund mode (backend config)

Per game, in the admin dashboard under **Games → Edit**:

| Mode | Behavior |
|------|----------|
| **Auto** (default) | Webhook → rewards deducted immediately → delivered on next login |
| **Manual** | Webhook → staff reviews in Orders page → approve/reject → then delivered |

---

## 7. Ads

Two namespaces both call themselves "label", and mixing them up is the most
common ads bug:

- a **place label** is your game's own moment — `"Revive"`, `"level_win"` —
  configured for your game in `iaa_config`;
- an **ad unit** is TikTok's, identified by an id, with its own name on the
  TikTok dashboard.

`ShowAdsRemote` takes the first; `ShowAd` takes the second.

### Where the config comes from

`iaa_config` and the active ad units ride in on the login response, so a game
that calls `TikTokAuth.Login` already has them — no extra round-trip.

A game that does **not** use our login still gets ads. If a place is asked for
before any config has arrived, `ShowAdsRemote` fetches it once from
`POST /api/ads/config` — keyed by game id, no session, same as the shop — and
then continues. If that fetch fails the callback reports it as `503` rather than
blaming the place label.

Ads-only integrations, and anything that gates a button on `ResolvePlace`,
should load it up front instead, since `ResolvePlace` is synchronous and cannot
wait for a fetch:

```csharp
TikTokAds.LoadRemoteConfig((ok, err) =>
{
    if (!ok) { Debug.LogWarning($"No ad config: {err}"); return; }
    BuildAdButtons();          // ResolvePlace works from here on
});
```

`TikTokAds.IsConfigLoaded` says whether anything has arrived yet.

### Ask before you offer

A place resolves through a waterfall of ad units, and a unit can be inactive or
on cooldown. Offering the player a Revive button that then fails is worse than
never drawing it, so ask first — `ResolvePlace` shows nothing and changes
nothing:

```csharp
using HS.TikTokSDK.Ads;

AdPlaceResolution r = TikTokAds.ResolvePlace("Revive");

reviveButton.gameObject.SetActive(r.resolved);
if (!r.resolved) Debug.Log($"No Revive ad right now: {r.reason}");

// r.waterfall walks the candidates in order, with why each was skipped:
foreach (var step in r.waterfall)
    Debug.Log($"{step.ad_id} {step.ad_type} active={step.active} " +
              $"cooldown_remaining={step.cooldown_remaining} {step.skip_reason}");
```

### Show one

```csharp
TikTokAds.ShowAdsRemote("Revive", result =>
{
    // Which ad actually ran — the waterfall picked it, not you.
    Debug.Log($"{result.place_label} → {result.ad_id} ({result.ad_type})");

    // Reward on `completed`, NEVER on `success` alone. `success` only means
    // the ad ran; `completed` means it was watched to the end.
    if (result.success && result.completed) GrantRevive();
    else if (!result.success) ShowMessage(result.error_message);
});
```

Direct, when you already know the unit:

```csharp
TikTokAds.ShowAd(new AdRequest { id = "7912…", type = "rewarded", context = "level_12_fail" }, OnAd);
```

`ShowAd` requires an id. To show any active unit of a type — a game with no
`iaa_config` yet, or a smoke test — use `ShowAdOfType`:

```csharp
TikTokAds.ShowAdOfType("rewarded", "level_12_fail", OnAd);
```

### Reading the config

| Call | Answers |
|------|---------|
| `TikTokAds.GetPlaceLabels()` | every place label configured for this game |
| `TikTokAds.GetPlacement(label)` | that label's waterfall as configured |
| `TikTokAds.ResolvePlace(label)` | what would run right now, and why not |
| `TikTokAds.GetCooldownRemaining(label, adId)` | seconds still to wait, 0 = ready |
| `TikTokAds.GetActivePlacements()` | ad units TikTok reports live for this game |
| `TikTokAds.GetActivePlacementsOfType(type)` | the same, filtered |
| `TikTokAds.GetRateLimits()` | requests this session, per minute/hour/day |
| `TikTokAds.GetAdLogs()` | every request this session |
| `TikTokAds.Config` / `RawIaaConfigJson` | the parsed / raw remote config |

All of it arrives with the login response, so it is empty until
`OnInitCompleted` fires:

```csharp
TikTokAds.OnInitCompleted += BuildAdButtons;
```

### Error codes

| Code | Meaning |
|------|---------|
| `400` | the request was malformed — a missing `AdRequest.id`, an empty label |
| `404` | nothing to show: no config for the place, or every unit inactive or on cooldown |
| `11004` | TikTok swallowed the show, almost always its own frequency cap |

Every failure calls your callback. None of them throws, and none of them is
silent.

---

## Architecture

```
Your Game Code                     HS TikTok SDK
┌──────────────────┐              ┌──────────────────────────┐
│ MySaveManager    │──implements──▶ ITikTokSyncProvider      │
│ MyShopController │──implements──▶ ITikTokRewardHandler     │
└──────────────────┘              │  ├─ OnPurchaseRewards    │
                                  │  ├─ OnPendingRecovered   │
                                  │  └─ OnRefundNotified     │
                                  │                          │
                                  │ TikTokSDK    (config)    │
         registers ──────────────▶│ TikTokAuth   (login)     │
                                  │ TikTokIAP    (purchases) │
                                  │ TikTokSync   (cloud)     │
                                  └──────────────────────────┘
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `SDK Key and Game ID appear to be SWAPPED` | Check Inspector — SDK Key starts with `sk_`, Game ID is numeric |
| `Cannot buy — player is not logged in` | `BuyProduct` logs in by itself now; if it still fails, read the `TikTokAuth.Login` result for why |
| `Already processing a purchase` | Wait for current purchase to complete (double-tap guard) |
| Purchases not working in Editor | Editor uses mock payments — test real payments on TikTok device |
| Sync not running | Ensure `RegisterSyncProvider()` is called and `IsDirtyForCloud = true` |
| Refund not showing | Refunds deliver on next login — or call `CheckRefunds()` mid-session |
| Player balance wrong after refund | Backend updates `profile_data` — reload from server after refund callback |
| Refund stuck in PENDING | Check admin dashboard — game may be in Manual refund mode |
| Ads all return 404 | No config loaded — log in, or `TikTokAds.LoadRemoteConfig()`, then check `ResolvePlace` |
| Login fails only on device | Read `result.failure` — `PluginMissing`/`PluginInitFailed` name the step |
