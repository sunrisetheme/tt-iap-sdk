using UnityEngine;
using HS.TikTokSDK;
using HS.TikTokSDK.Auth;

/// <summary>
/// SAMPLE: LOGIN — one call, and what to do with the answer.
///
/// TikTokAuth.Login() does the whole chain:
///
///   1. Initialises TikTok's plugin if that has not happened (and turns on
///      TikTok's Editor mocks, so an ad in the Editor is a real mock ad and
///      not an instant silent success).
///   2. Gets an auth code from TikTok. In test mode — anything that is not a
///      TikTok WebGL build — it skips this and uses a device-derived test id,
///      so the same call works in the Editor.
///   3. Exchanges the code with the backend for a session.
///   4. Reports ONE result.
///
/// You do not call TT.InitSDK, TT.Login or LoginWithCode yourself. Those are
/// still public for a game with an unusual flow, but the ordering between them
/// is the part that used to go wrong, and it is no longer yours to get right.
///
/// After success the SDK has already: stored the session, applied server config,
/// initialised the ad module with this game's remote config, delivered pending
/// rewards and refunds, and fired OnLoginSuccess with the cloud save.
/// </summary>
public class SampleLoginHandler : MonoBehaviour
{
    [Header("UI References (optional)")]
    public GameObject loadingPanel;
    public GameObject errorPanel;
    public GameObject retryButton;

    private void Start()
    {
        // The event still fires, and it is the right place to READ the login —
        // the cloud save arrives with it. The result below is for deciding what
        // the UI does next.
        TikTokAuth.Instance.OnLoginSuccess += HandleCloudData;

        StartLogin();
    }

    private void OnDestroy()
    {
        if (TikTokAuth.Instance != null)
            TikTokAuth.Instance.OnLoginSuccess -= HandleCloudData;
    }

    // ═══════════════════════════════════════════════════
    //  Logging in
    // ═══════════════════════════════════════════════════

    public void StartLogin()
    {
        if (loadingPanel != null) loadingPanel.SetActive(true);
        if (errorPanel != null) errorPanel.SetActive(false);

        TikTokAuth.Instance.Login(result =>
        {
            if (loadingPanel != null) loadingPanel.SetActive(false);

            if (result.success)
            {
                Debug.Log($"[Login] Signed in as {result.openId}");
                // YourGame.LoadMainMenu();
                return;
            }

            HandleFailure(result);
        });
    }

    // ═══════════════════════════════════════════════════
    //  Failures
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// The reason is typed, because the question the UI has is not "what went
    /// wrong" but "what do I draw now" — and those are different answers.
    ///
    /// Two flags cover most of it without a switch at all:
    ///   IsIntegrationError  a developer has to fix it; no button will help.
    ///   IsRetryable         trying again could plausibly work.
    /// </summary>
    private void HandleFailure(TikTokLoginResult result)
    {
        Debug.LogWarning($"[Login] {result}");

        if (result.IsIntegrationError)
        {
            // Do not show a player a retry button for this. It will never work,
            // and the loop hides the real cause from whoever could fix it.
            Debug.LogError($"[Login] INTEGRATION ERROR ({result.failure}): {result.message}");
            // YourGame.ShowFatal("Something is wrong with this build.");
            return;
        }

        switch (result.failure)
        {
            case TikTokLoginFailure.UserCancelled:
                // Not an error. The player said no; let them say yes later.
                // YourGame.ShowLoginButton();
                break;

            case TikTokLoginFailure.NetworkError:
                // YourGame.ShowMessage("No connection. Check your network.");
                break;

            case TikTokLoginFailure.BackendRejected:
                // The backend answered and refused. Retrying rarely helps, but
                // the message says why, and it is worth surfacing to support.
                // YourGame.ShowMessage("Could not sign in right now.");
                break;

            case TikTokLoginFailure.PluginInitFailed:
                // TikTok's own plugin did not come up. Usually transient.
                // YourGame.ShowMessage("TikTok is not responding. Try again.");
                break;
        }

        if (errorPanel != null) errorPanel.SetActive(true);
        if (retryButton != null) retryButton.SetActive(result.IsRetryable);
    }

    public void OnRetryButtonClicked() => StartLogin();

    // ═══════════════════════════════════════════════════
    //  The cloud save
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// profileJson is the player's cloud save, or empty on a first login.
    /// serverTimestamp is when the server last saw it — compare it against your
    /// local save's timestamp to decide which one wins.
    /// </summary>
    private void HandleCloudData(string profileJson, long serverTimestamp)
    {
        if (string.IsNullOrEmpty(profileJson))
        {
            Debug.Log("[Login] No cloud save — new player.");
            // YourGame.StartFreshProfile();
            return;
        }

        Debug.Log($"[Login] Cloud save received ({profileJson.Length} chars, ts={serverTimestamp})");
        // var cloud = JsonUtility.FromJson<MyPlayerData>(profileJson);
        // if (serverTimestamp > YourGame.LocalTimestamp) YourGame.Apply(cloud);
    }

    // ═══════════════════════════════════════════════════
    //  Already doing your own TT.InitSDK?
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// If your game already calls TT.InitSDK in its own bootstrap, tell the SDK
    /// so it does not call it a second time — TikTok does not document that as
    /// safe. Call this from your init callback, before any Login().
    ///
    /// Simpler still: delete your own call and let the SDK do it.
    /// </summary>
    public void IAlreadyInitialisedTheTikTokPlugin()
    {
        TikTokPlatform.MarkReady();
    }
}
