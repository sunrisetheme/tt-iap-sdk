using System;
using UnityEngine;
using HS.TikTokSDK.Missions;

/// <summary>
/// SAMPLE: MISSIONS — TikTok tasks the player completes for a reward.
///
///   EntranceMission   opens the game's TikTok profile, then verifies on return.
///   ShortcutMission   shows TikTok's "add to home screen" dialog, then verifies.
///
/// The split matters. The SDK reports ONE thing: whether TikTok accepted the
/// mission. Everything else is yours —
///
///   • what the mission is worth
///   • whether it can be claimed again today, or ever
///   • what the button says while it is running
///
/// Missions are OPTIONAL and none is enabled by default. Nothing happens until
/// you Register() the ones your game offers, which is also what stops a game
/// that wants one mission from shipping the other.
///
/// Setup:
///   1. TikTokMissions must be on the HS_TikTokSDK object. IAP TikTok Setup ▸
///      Setup SDK in Scene adds it. If you built your scene before missions
///      existed, add the component by hand — the setup tool will not touch a
///      scene that already has an SDK object.
///   2. Attach this script anywhere.
///   3. Call StartEntranceMission() / StartShortcutMission() from your buttons.
/// </summary>
public class SampleMissionsHandler : MonoBehaviour
{
    [Header("Rewards — your game's numbers, not the SDK's")]
    [SerializeField] private int entranceReward = 50;
    [SerializeField] private int shortcutReward = 30;

    private void Start()
    {
        var missions = TikTokMissions.Instance;
        if (missions == null)
        {
            Debug.LogError("[Missions] TikTokMissions is not in the scene — add the component " +
                           "to HS_TikTokSDK. Without it Execute() can never run.");
            return;
        }

        // Register only what this game offers. Registering is idempotent, so it
        // is safe if two scripts each register their own mission.
        missions.Register(new EntranceMission());
        missions.Register(new ShortcutMission());

        missions.OnMissionResult += HandleMissionResult;

        Debug.Log($"[Missions] Registered: {string.Join(", ", missions.RegisteredTypes)}");
        RefreshButtons();
    }

    private void OnDestroy()
    {
        if (TikTokMissions.Instance != null)
            TikTokMissions.Instance.OnMissionResult -= HandleMissionResult;
    }

    // ═══════════════════════════════════════════════════
    //  Starting a mission
    // ═══════════════════════════════════════════════════

    public void StartEntranceMission() => Execute(MissionType.EntranceMission);
    public void StartShortcutMission() => Execute(MissionType.ShortcutMission);

    private void Execute(MissionType type)
    {
        var missions = TikTokMissions.Instance;
        if (missions == null) return;

        // EntranceMission sends the player out to TikTok and finishes only when
        // they come back, which can be a while — or never. Show that state, and
        // do not let a second tap start a second attempt.
        Debug.Log($"[Missions] Execute({type})");
        // YourGame.SetMissionButtonBusy(type, true);

        missions.Execute(type);
    }

    // ═══════════════════════════════════════════════════
    //  The result
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// One event for every mission, so filter by type.
    ///
    /// It fires for refusals too — an unregistered mission, or one already
    /// running — so a button put into a spinner by Execute() always comes back
    /// out. It is safe to treat this as "the attempt is over", whatever happened.
    /// </summary>
    private void HandleMissionResult(MissionResult result)
    {
        // YourGame.SetMissionButtonBusy(result.Type, false);

        if (!result.IsSuccess)
        {
            // Not an exception. The usual cause is the player: they closed
            // TikTok's dialog, or came back without finishing.
            Debug.Log($"[Missions] {result.Type} not completed — {result.Error}");
            // YourGame.ShowToast("Mission not completed yet.");
            return;
        }

        Debug.Log($"[Missions] {result.Type} confirmed by TikTok.");
        Claim(result.Type);
    }

    // ═══════════════════════════════════════════════════
    //  Your half: the guard and the payout
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// TikTok will happily confirm the same mission again — it reports whether
    /// the task is done, not whether YOU have already paid for it. So the claim
    /// guard is the game's, and skipping it is how a daily reward becomes
    /// infinite.
    ///
    /// PlayerPrefs here to keep the sample self-contained; in a real game put it
    /// in the save data that syncs to the cloud, or the player gets the daily
    /// gift again on every new device.
    /// </summary>
    private void Claim(MissionType type)
    {
        switch (type)
        {
            case MissionType.EntranceMission:
                // Daily.
                string today = DateTime.UtcNow.ToString("yyyy-MM-dd");
                if (PlayerPrefs.GetString("EntranceClaimDate", "") == today)
                {
                    Debug.Log("[Missions] Entrance already claimed today.");
                    // YourGame.ShowToast("Come back tomorrow!");
                    return;
                }
                PlayerPrefs.SetString("EntranceClaimDate", today);
                PlayerPrefs.Save();

                Debug.Log($"[Missions] +{entranceReward} coins");
                // YourGame.AddCoins(entranceReward);
                break;

            case MissionType.ShortcutMission:
                // Once ever — the shortcut only gets added once.
                if (PlayerPrefs.GetInt("ShortcutClaimed", 0) == 1)
                {
                    Debug.Log("[Missions] Shortcut already claimed.");
                    return;
                }
                PlayerPrefs.SetInt("ShortcutClaimed", 1);
                PlayerPrefs.Save();

                Debug.Log($"[Missions] +{shortcutReward} coins");
                // YourGame.AddCoins(shortcutReward);
                break;
        }

        RefreshButtons();
    }

    private void RefreshButtons()
    {
        var missions = TikTokMissions.Instance;
        if (missions == null) return;

        // Build the mission UI from what is actually registered, rather than
        // hard-coding a list and hoping registration matched it.
        foreach (var type in missions.RegisteredTypes)
        {
            bool busy = missions.IsProcessing(type);
            Debug.Log($"[Missions] {type}: registered, processing={busy}");
            // YourGame.SetMissionButton(type, busy);
        }
    }
}
