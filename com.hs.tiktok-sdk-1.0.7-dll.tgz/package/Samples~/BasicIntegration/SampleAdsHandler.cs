using UnityEngine;
using HS.TikTokSDK.Ads;

/// <summary>
/// SAMPLE: ADS — rewarded and interstitial, driven by remote config.
///
/// Two things are called "label" and they are NOT the same:
///
///   PLACE LABEL   your game's own moment — "revive", "level_win", "free_hint".
///                 You choose these, and they go in this game's iaa_config.
///   AD UNIT       TikTok's, identified by an id like "ad7635013883317733396",
///                 with its own name on the TikTok dashboard.
///
/// You pass the FIRST kind. The SDK walks that place's waterfall and picks the
/// first unit that is active and off cooldown. That is what lets you change
/// which ad plays, or add a fallback unit, without shipping a build.
///
/// Setup:
///   1. SampleTikTokBootstrap must have run and the player must be logged in —
///      iaa_config arrives with the login response.
///   2. Attach this to a GameObject.
///   3. Call ShowReviveAd() / ShowInterstitial() from your UI.
/// </summary>
public class SampleAdsHandler : MonoBehaviour
{
    [Header("Place labels — must match this game's iaa_config")]
    [SerializeField] private string revivePlace = "revive";
    [SerializeField] private string interstitialPlace = "level_win";

    private void Start()
    {
        // Nothing below can be answered before this fires: the whole ad config
        // travels in the login response, so on a cold start GetPlaceLabels() is
        // empty and every place "resolves to nothing" until it arrives.
        TikTokAds.OnInitCompleted += OnAdConfigReady;
    }

    private void OnDestroy()
    {
        TikTokAds.OnInitCompleted -= OnAdConfigReady;
    }

    private void OnAdConfigReady()
    {
        var labels = TikTokAds.GetPlaceLabels();
        Debug.Log($"[Ads] Config ready — {labels.Count} place(s): {string.Join(", ", labels)}");

        // Worth logging once at startup. "The ad did nothing" is a hard bug to
        // chase; "the place 'revive' is not in this game's iaa_config" is not.
        foreach (var label in labels)
        {
            var r = TikTokAds.ResolvePlace(label);
            Debug.Log($"[Ads]   '{label}' → " +
                      (r.resolved ? $"{r.ad_id} ({r.ad_type})" : $"nothing — {r.reason}"));
        }

        RefreshReviveButton();
    }

    // ═══════════════════════════════════════════════════
    //  Ask before you offer
    // ═══════════════════════════════════════════════════

    /// <summary>
    /// Whether an ad could play at this place RIGHT NOW.
    ///
    /// A place can come up empty for reasons that have nothing to do with the
    /// player: every unit in its waterfall inactive, or all of them still on
    /// cooldown. Offering a Revive button that then fails is worse than never
    /// drawing it, so ask first. ResolvePlace shows nothing, starts no cooldown
    /// and costs no rate limit — it only reports.
    /// </summary>
    private void RefreshReviveButton()
    {
        var resolution = TikTokAds.ResolvePlace(revivePlace);

        // YourGame.reviveButton.gameObject.SetActive(resolution.resolved);

        if (resolution.resolved)
        {
            Debug.Log($"[Ads] Revive is available — would play {resolution.ad_id} ({resolution.ad_type})");
            return;
        }

        Debug.Log($"[Ads] Revive unavailable — {resolution.reason}");

        // The waterfall says WHY, entry by entry, which is the difference
        // between "misconfigured" and "just used it, come back in 30s".
        foreach (var step in resolution.waterfall)
        {
            Debug.Log($"[Ads]   {step.ad_id} · active={step.active}" +
                      (step.cooldown_remaining > 0 ? $" · {step.cooldown_remaining:F0}s left" : "") +
                      (string.IsNullOrEmpty(step.skip_reason) ? "" : $" · {step.skip_reason}"));
        }
    }

    // ═══════════════════════════════════════════════════
    //  Rewarded
    // ═══════════════════════════════════════════════════

    public void ShowReviveAd()
    {
        Debug.Log($"[Ads] ShowAdsRemote(\"{revivePlace}\")");

        TikTokAds.ShowAdsRemote(revivePlace, result =>
        {
            // The result names the ad that actually ran. You did not choose it —
            // the waterfall did — so without these you cannot log which unit
            // paid, tell two units at one place apart, or quote an id in a
            // support ticket.
            Debug.Log($"[Ads] place={result.place_label} id={result.ad_id} type={result.ad_type} " +
                      $"success={result.success} completed={result.completed} " +
                      $"code={result.error_code} {result.error_message}");

            // ── The one rule that matters ──────────────────────
            // Reward on COMPLETED, never on success alone.
            //   success   = the ad ran
            //   completed = it was watched to the end
            // Rewarding on success pays a player who closed it after a second,
            // and it is the single most common rewarded-ad bug.
            if (result.success && result.completed)
            {
                Debug.Log("[Ads] Watched — granting the revive.");
                // YourGame.GrantRevive();
                return;
            }

            if (result.success)
            {
                // Closed early. Not an error, and not a reward. Tell the UI, or
                // whatever popup is waiting on this stays open forever.
                Debug.Log("[Ads] Closed early — no reward.");
                // YourGame.CloseReviveOffer();
                return;
            }

            OnAdFailed(result);
        });
    }

    /// <summary>
    /// No iaa_config yet? This shows the first active unit of a type, skipping
    /// remote config entirely. Fine for a smoke test, not for shipping — it
    /// cannot rotate units or honour a cooldown.
    /// </summary>
    public void ShowAnyRewardedAd()
    {
        TikTokAds.ShowAdOfType("rewarded", "smoke_test", result =>
            Debug.Log($"[Ads] any-rewarded → {result.ad_id} success={result.success} completed={result.completed}"));
    }

    // ═══════════════════════════════════════════════════
    //  Interstitial
    // ═══════════════════════════════════════════════════

    public void ShowInterstitial()
    {
        TikTokAds.ShowAdsRemote(interstitialPlace, result =>
        {
            // An interstitial has nothing to grant, so the only thing that
            // matters is letting the game continue — on success AND on failure.
            // A flow that only resumes on success stalls the moment TikTok
            // declines to serve one, which it does routinely.
            if (!result.success)
                Debug.Log($"[Ads] Interstitial not shown ({result.error_code}) — continuing anyway.");

            // YourGame.ContinueToNextLevel();
        });
    }

    // ═══════════════════════════════════════════════════
    //  Failures
    // ═══════════════════════════════════════════════════

    private void OnAdFailed(AdResult result)
    {
        switch (result.error_code)
        {
            case 400:
                // Malformed request — an empty place label, or ShowAd with no id.
                Debug.LogError($"[Ads] Bad request: {result.error_message}");
                break;

            case 404:
                // Nothing to show: no config for this place, or every unit
                // inactive or on cooldown. An answer, not a fault — retrying
                // immediately returns the same thing.
                Debug.LogWarning($"[Ads] Nothing available: {result.error_message}");
                break;

            case 11004:
                // TikTok's own frequency cap. Retrying never succeeds.
                Debug.LogWarning("[Ads] Frequency cap — skip the ad, do not retry.");
                break;

            default:
                Debug.LogError($"[Ads] Failed ({result.error_code}): {result.error_message}");
                break;
        }

        // Whatever the reason, unblock the game.
        // YourGame.CloseReviveOffer();
    }

    // ═══════════════════════════════════════════════════
    //  Diagnostics
    // ═══════════════════════════════════════════════════

    /// <summary>Everything the SDK knows about ads, for a bug report.</summary>
    public void DumpAdState()
    {
        var limits = TikTokAds.GetRateLimits();
        Debug.Log($"[Ads] rewarded: {limits.reward.count} total, {limits.reward.per_min}/min, {limits.reward.per_hour}/hr\n" +
                  $"[Ads] interstitial: {limits.inter.count} total, {limits.inter.per_min}/min, {limits.inter.per_hour}/hr");

        foreach (var unit in TikTokAds.GetActivePlacements())
            Debug.Log($"[Ads] active unit {unit.id} · {unit.type} · {unit.status}");

        foreach (var entry in TikTokAds.GetAdLogs())
            Debug.Log($"[Ads] past request {entry.request?.id} → success={entry.result?.success}");
    }
}
