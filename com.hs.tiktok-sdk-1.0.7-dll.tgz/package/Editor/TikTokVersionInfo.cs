using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace HS.TikTokSDK.Editor
{
    /// <summary>
    /// What is actually installed, and where.
    ///
    /// "Which version?" is the first question on every bug report and the one
    /// nothing in the Editor could answer. Both packages hide it in a different
    /// place: the HS SDK is a UPM package, so the Package Manager knows; TikTok's
    /// plugin is usually dropped into Assets/Plugins, where nothing knows —
    /// its version lives only in a package.json next to the DLLs, and the API
    /// version it corresponds to only in that file's changelog blob.
    ///
    /// Everything here is read from disk rather than from the running plugin.
    /// TTSDK's own version properties reach for the native bridge, which does
    /// not exist in the Editor, and a diagnostic that throws is worse than one
    /// that says "unknown".
    /// </summary>
    internal static class TikTokVersionInfo
    {
        // ─── HS TikTok SDK ──────────────────────────────────────

        public static string HsVersion { get; private set; } = "unknown";

        /// <summary>"local source", "registry", "embedded" — how it was installed.</summary>
        public static string HsSource { get; private set; } = "";

        public static string HsPath { get; private set; } = "";

        // ─── TikTok's plugin ────────────────────────────────────

        /// <summary>The package's own version, e.g. "1.1.5-Release".</summary>
        public static string TtPackageVersion { get; private set; } = "not installed";

        /// <summary>The TTSDK API version that package ships, e.g. "6.5.5".</summary>
        public static string TtApiVersion { get; private set; } = "";

        /// <summary>
        /// Date and size of ttsdk.dll — the only thing that reliably tells two
        /// drops apart.
        ///
        /// TikTok does not fill the version in consistently: a drop from March
        /// declares "1.0.0" and one from July declares "1.1.5-Release", and both
        /// embed the same 6.5.5 changelog, while the DLLs differ by 180 KB. The
        /// assembly carries no version either — it is built as 0.0.0.0. So when
        /// the declared version looks wrong, this is what answers "is this the
        /// package I think I installed".
        /// </summary>
        public static string TtBinary { get; private set; } = "";

        public static string TtPath { get; private set; } = "";

        public static bool TtInstalled => TtPath != "";

        // ─── Probe ──────────────────────────────────────────────

        static TikTokVersionInfo() { Refresh(); }

        public static void Refresh()
        {
            ProbeHs();
            ProbeTikTok();
        }

        private static void ProbeHs()
        {
            HsVersion = "unknown";
            HsSource = "";
            HsPath = "";

            try
            {
                var asm = typeof(TikTokSDK).Assembly;
                var pkg = UnityEditor.PackageManager.PackageInfo.FindForAssembly(asm);

                if (pkg != null)
                {
                    HsVersion = pkg.version;
                    HsPath = Shorten(pkg.resolvedPath);

                    // Worth naming, because it changes what you are testing. A
                    // local source install is the repo live — edits apply on
                    // recompile. A registry or tarball install is the compiled
                    // DLL a partner receives, and edits to the repo do nothing.
                    switch (pkg.source)
                    {
                        case UnityEditor.PackageManager.PackageSource.Local:
                            HsSource = "local source"; break;
                        case UnityEditor.PackageManager.PackageSource.LocalTarball:
                            HsSource = "local .tgz"; break;
                        case UnityEditor.PackageManager.PackageSource.Embedded:
                            HsSource = "embedded"; break;
                        case UnityEditor.PackageManager.PackageSource.Registry:
                            HsSource = "registry"; break;
                        default:
                            HsSource = pkg.source.ToString().ToLowerInvariant(); break;
                    }
                    return;
                }

                // Not a package at all — the SDK was copied into Assets. Read
                // the package.json beside it if there is one.
                string manifest = FindManifestNear(asm.Location);
                if (manifest != null)
                {
                    HsVersion = ReadVersion(manifest) ?? "unknown";
                    HsPath = Shorten(Path.GetDirectoryName(manifest));
                }
                HsSource = "in Assets, not a package";
            }
            catch (Exception e)
            {
                HsSource = "could not be read — " + e.GetType().Name;
            }
        }

        private static void ProbeTikTok()
        {
            TtPackageVersion = "not installed";
            TtApiVersion = "";
            TtBinary = "";
            TtPath = "";

            try
            {
                // By type, not by folder name. The plugin has shipped under
                // com.tiktok.minigame and com.tiktok.ttsdk, and can be installed
                // as a UPM package instead — the assembly holding TTSDK.TT is
                // the one thing that is true in every case.
                var asm = AppDomain.CurrentDomain.GetAssemblies()
                    .FirstOrDefault(a => { try { return a.GetType("TTSDK.TT") != null; } catch { return false; } });

                if (asm == null) return;

                TtBinary = DescribeBinary(asm.Location);

                string manifest = FindManifestNear(asm.Location);
                if (manifest == null)
                {
                    TtPackageVersion = "installed, version unknown";
                    TtPath = Shorten(Path.GetDirectoryName(asm.Location));
                    return;
                }

                string json = File.ReadAllText(manifest);
                TtPackageVersion = ReadVersion(manifest) ?? "installed, version unknown";
                TtPath = Shorten(Path.GetDirectoryName(manifest));

                // The API version is not a field. TTSDK's package.json carries
                // its whole changelog inside "description", newest first, each
                // release headed by a bracketed number — so the first one is the
                // version of TT.* this package actually exposes.
                var m = Regex.Match(json, @"\[(\d+\.\d+(?:\.\d+)?)\]");
                if (m.Success) TtApiVersion = m.Groups[1].Value;
            }
            catch (Exception e)
            {
                TtPackageVersion = "could not be read — " + e.GetType().Name;
            }
        }

        // ─── Helpers ────────────────────────────────────────────

        /// <summary>
        /// Walks up from a compiled assembly looking for the package.json that
        /// describes it. Five levels covers Runtime/, TTSDK/, Editor/ and the
        /// nesting UPM adds; going further starts finding other packages'.
        /// </summary>
        private static string FindManifestNear(string assemblyPath)
        {
            if (string.IsNullOrEmpty(assemblyPath)) return null;

            var dir = Directory.Exists(assemblyPath)
                ? new DirectoryInfo(assemblyPath)
                : new DirectoryInfo(Path.GetDirectoryName(assemblyPath) ?? "");

            for (int i = 0; i < 5 && dir != null && dir.Exists; i++, dir = dir.Parent)
            {
                string candidate = Path.Combine(dir.FullName, "package.json");
                if (File.Exists(candidate)) return candidate;
            }
            return null;
        }

        private static string DescribeBinary(string path)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return "";
                var f = new FileInfo(path);
                return f.Name + " " + f.LastWriteTime.ToString("yyyy-MM-dd") +
                       ", " + (f.Length / 1024) + " KB";
            }
            catch { return ""; }
        }

        private static string ReadVersion(string manifestPath)
        {
            try
            {
                // Regex rather than JsonUtility: TTSDK's description field is a
                // multi-kilobyte changelog with newlines and quotes in it, and
                // one malformed escape would take the version down with it. Only
                // one field is wanted here.
                var m = Regex.Match(File.ReadAllText(manifestPath), "\"version\"\\s*:\\s*\"([^\"]+)\"");
                return m.Success ? m.Groups[1].Value : null;
            }
            catch { return null; }
        }

        /// <summary>Project-relative when it is inside the project, absolute otherwise.</summary>
        private static string Shorten(string path)
        {
            if (string.IsNullOrEmpty(path)) return "";
            path = path.Replace('\\', '/');

            string projectRoot = Path.GetDirectoryName(Application.dataPath)?.Replace('\\', '/');
            if (!string.IsNullOrEmpty(projectRoot) && path.StartsWith(projectRoot, StringComparison.Ordinal))
            {
                string rel = path.Substring(projectRoot.Length).TrimStart('/');
                return rel.Length > 0 ? rel : ".";
            }
            return path;
        }

        /// <summary>One block, for pasting into a bug report.</summary>
        public static string Report()
        {
            return
                "HS TikTok SDK   " + HsVersion + (HsSource != "" ? "  (" + HsSource + ")" : "") + "\n" +
                "                " + HsPath + "\n" +
                "TikTok TTSDK    " + TtPackageVersion +
                    (TtApiVersion != "" ? "  (API " + TtApiVersion + ")" : "") + "\n" +
                "                " + TtPath + (TtBinary != "" ? "  ·  " + TtBinary : "") + "\n" +
                "Project         " + Path.GetFileName(
                                        Path.GetDirectoryName(Application.dataPath) ?? "") + "\n" +
                "Unity           " + Application.unityVersion + "\n" +
                "Build target    " + EditorUserBuildSettings.activeBuildTarget + "\n" +
                "Defines         " + (PlayerSettings.GetScriptingDefineSymbolsForGroup(
                                        BuildPipeline.GetBuildTargetGroup(
                                            EditorUserBuildSettings.activeBuildTarget)) ?? "");
        }
    }
}
