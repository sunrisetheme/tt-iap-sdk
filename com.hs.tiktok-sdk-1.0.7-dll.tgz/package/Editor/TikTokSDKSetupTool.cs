#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEngine;
using HS.TikTokSDK;
using HS.TikTokSDK.Auth;
using HS.TikTokSDK.IAP;
using HS.TikTokSDK.Sync;

namespace HS.TikTokSDK.Editor
{
    /// <summary>
    /// Builds — and repairs — the HS_TikTokSDK object.
    ///
    /// It used to refuse outright when an object of that name existed, which
    /// deadlocked the one case that needs it most. Swap the SDK between a source
    /// install and the DLL package and the four components that live in the DLL
    /// lose their script: a scene stores {fileID, guid}, and a .cs file's guid is
    /// not the assembly's. TikTokMissions survives, because it ships as source in
    /// both and keeps its guid — which is why the Inspector shows four missing
    /// scripts and one intact.
    ///
    /// The checklist then read "no SDK object" (the component is gone) while this
    /// read "already exists" (the GameObject is not), and the button the
    /// checklist offered was the one that refused. Nothing could break the tie.
    /// So this now tops up whatever it finds instead of walking away.
    /// </summary>
    public class TikTokSDKSetupTool
    {
        private const string SDK_NAME = "HS_TikTokSDK";

        // No longer a menu item. It did step two of four and silently, which is
        // why the Integration Checklist exists — and two entry points meant the
        // one that skipped the other three was the one people found first.
        // The checklist calls this; so does the QA scene builder.
        public static void SetupSDK()
        {
            var sdkObj = FindSdkObject();
            bool created = sdkObj == null;
            if (created) sdkObj = new GameObject(SDK_NAME);

            // The WebGL bridge finds this object by name at the scene root.
            sdkObj.name = SDK_NAME;
            if (sdkObj.transform.parent != null) sdkObj.transform.SetParent(null);

            // Orphaned components have to go before the real ones are added:
            // Unity will not attach a second TikTokSDK while a missing script
            // occupies the slot, and a missing script cannot be repointed from
            // script — only removed.
            int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(sdkObj);

            // Whatever the missing scripts were holding is unreachable once the
            // type is gone, credentials included. Re-seed them from the last set
            // this project saw rather than making someone find the sk_live_ key
            // again.
            string rememberedGameId = EditorPrefs.GetString(KeyFor("gameId"), "");
            string rememberedSdkKey = EditorPrefs.GetString(KeyFor("sdkKey"), "");

            var core = Ensure<TikTokSDK>(sdkObj);
            if (string.IsNullOrWhiteSpace(core.gameId) && !string.IsNullOrWhiteSpace(rememberedGameId))
                core.gameId = rememberedGameId;
            if (string.IsNullOrWhiteSpace(core.sdkKey) && !string.IsNullOrWhiteSpace(rememberedSdkKey))
                core.sdkKey = rememberedSdkKey;

            Ensure<TikTokAuth>(sdkObj);
            Ensure<TikTokIAP>(sdkObj);

            var sync = Ensure<TikTokSync>(sdkObj);
            if (sync.syncIntervalSeconds <= 0f) sync.syncIntervalSeconds = 10f;

            // Added by type name rather than directly, because where the type
            // lives depends on how the SDK was installed. The mission scripts
            // ship as source — they compile against the partner's own
            // TTSDK_MIX_ENGINE — so in a DLL install they land in their own
            // assembly, which this Editor assembly does not reference. Looking
            // the type up works in both shapes, and skips cleanly if a build
            // ever ships without missions.
            var missionsType = FindType("HS.TikTokSDK.Missions.TikTokMissions");
            if (missionsType != null)
            {
                if (sdkObj.GetComponent(missionsType) == null) sdkObj.AddComponent(missionsType);
            }
            else
            {
                Debug.LogWarning("[HS.TikTokSDK] Missions component not found — " +
                                 "TikTokMissions.Instance will be null and Execute() will do nothing.");
            }

            Selection.activeGameObject = sdkObj;
            EditorUtility.SetDirty(sdkObj);
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(
                UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene());

            if (created)
            {
                Debug.Log("<b>[HS.TikTokSDK] SDK object created.</b> Enter your Game Id and Sdk Key.");
            }
            else
            {
                Debug.Log($"<b>[HS.TikTokSDK] SDK object repaired.</b> Removed {removed} broken " +
                          "component(s) and restored the missing ones" +
                          (string.IsNullOrWhiteSpace(core.sdkKey) ? "." : ", credentials included."));
            }
        }

        /// <summary>True when the object is there but its SDK component is not.</summary>
        public static bool NeedsRepair()
        {
            var obj = FindSdkObject();
            return obj != null && obj.GetComponent<TikTokSDK>() == null;
        }

        /// <summary>
        /// Remembers the credentials so a repair can put them back.
        ///
        /// Per project, not globally: one machine works on more than one game,
        /// and re-seeding a scene with another game's key produces a 401 that
        /// looks like an SDK fault.
        /// </summary>
        public static void RememberCredentials(string gameId, string sdkKey)
        {
            if (!string.IsNullOrWhiteSpace(gameId)) EditorPrefs.SetString(KeyFor("gameId"), gameId);
            if (!string.IsNullOrWhiteSpace(sdkKey)) EditorPrefs.SetString(KeyFor("sdkKey"), sdkKey);
        }

        private static string KeyFor(string field) =>
            "HS.TikTokSDK.Setup." + field + "." + Application.dataPath.GetHashCode();

        private static T Ensure<T>(GameObject go) where T : Component
        {
            var existing = go.GetComponent<T>();
            return existing != null ? existing : go.AddComponent<T>();
        }

        /// <summary>
        /// Finds the object by name, including one whose scripts are all broken.
        ///
        /// GameObject.Find would do, except it skips inactive objects — and an
        /// object disabled while someone was working out why it stopped working
        /// is exactly the one that needs repairing.
        /// </summary>
        private static GameObject FindSdkObject()
        {
            var scene = UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene();
            if (!scene.IsValid()) return null;

            return scene.GetRootGameObjects().FirstOrDefault(g => g.name == SDK_NAME)
                ?? GameObject.Find(SDK_NAME);
        }

        /// <summary>Locate a type by full name across whichever assembly holds it.</summary>
        private static System.Type FindType(string fullName)
        {
            foreach (var asm in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    var t = asm.GetType(fullName);
                    if (t != null) return t;
                }
                catch
                {
                    // An assembly that cannot be reflected over is not the one.
                }
            }
            return null;
        }
    }
}
#endif
