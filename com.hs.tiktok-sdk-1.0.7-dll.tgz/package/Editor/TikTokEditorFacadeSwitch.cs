using System;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace HS.TikTokSDK.Editor
{
    /// <summary>
    /// Turns the DLL package's Editor facade (Editor/TTSDKFacade/ttsdk.dll) on
    /// for the TikTok plugin layout that needs it, and off for the one it would
    /// break.
    ///
    ///   TikTok plugin 1.1.x — API split into ttsdk.dll (WebGL) and
    ///   ttsdk-editor.dll (Editor). The precompiled SDK names "ttsdk", which
    ///   the Editor does not load, so the facade (an assembly named ttsdk that
    ///   forwards to ttsdk-editor) has to be active.
    ///
    ///   TikTok plugin 1.0.x — one ttsdk.dll, active in the Editor too. The SDK
    ///   binds to it directly, and a second assembly named ttsdk would be a
    ///   duplicate Unity refuses to load. The facade must stay off.
    ///
    /// The facade carries the define constraint HS_TTSDK_EDITOR_ASSEMBLY; this
    /// sets that define when ttsdk-editor is present and removes it when not.
    /// Defines are per build target, so it re-checks when the target changes.
    /// Harmless in the source package, which ships no facade.
    /// </summary>
    [InitializeOnLoad]
    internal static class TikTokEditorFacadeSwitch
    {
        internal const string Define = "HS_TTSDK_EDITOR_ASSEMBLY";
        private const string EditorAssembly = "ttsdk-editor";

        static TikTokEditorFacadeSwitch()
        {
            // After the domain has finished loading, and never mid-import.
            EditorApplication.delayCall += Apply;
        }

        internal static void Apply()
        {
            bool split = AppDomain.CurrentDomain.GetAssemblies()
                .Any(a => string.Equals(a.GetName().Name, EditorAssembly, StringComparison.Ordinal));

            var group = BuildPipeline.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);
            if (group == BuildTargetGroup.Unknown) return;

            var defines = (PlayerSettings.GetScriptingDefineSymbolsForGroup(group) ?? "")
                .Split(';').Select(d => d.Trim()).Where(d => d.Length > 0).ToList();

            bool has = defines.Contains(Define);
            if (split == has) return;

            if (split) defines.Add(Define);
            else defines.Remove(Define);

            PlayerSettings.SetScriptingDefineSymbolsForGroup(group, string.Join(";", defines));
            Debug.Log("[HS.TikTokSDK] " + (split
                ? $"TikTok plugin ships ttsdk-editor.dll — added {Define} for {group} so the SDK's Editor facade loads."
                : $"TikTok plugin has no ttsdk-editor.dll — removed {Define} for {group}; the SDK uses TikTok's ttsdk.dll directly."));
        }

        /// <summary>Defines are per target group: check again after a platform switch.</summary>
        private class OnTargetChanged : IActiveBuildTargetChanged
        {
            public int callbackOrder => 0;
            public void OnActiveBuildTargetChanged(BuildTarget previous, BuildTarget current) => Apply();
        }
    }
}
