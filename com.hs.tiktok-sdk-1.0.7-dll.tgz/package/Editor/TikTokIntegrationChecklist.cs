using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

namespace HS.TikTokSDK.Editor
{
    /// <summary>
    /// Integration checklist — the window that tells an integrator what is still
    /// missing, in the order it has to be fixed.
    ///
    /// "Setup SDK in Scene" only ever did step two of four, and silently. The
    /// other three failed at runtime, on device, as a symptom rather than a
    /// cause: no TikTok plugin meant missions quietly simulated success, a wrong
    /// SDK key meant every request came back 403, and a scene that was never
    /// saved meant the SDK object was simply gone next launch.
    ///
    /// Each row states what is wrong and offers the fix it can perform. The one
    /// step that cannot be automated — importing TikTok's own package — says so
    /// rather than pretending.
    /// </summary>
    public class TikTokIntegrationChecklist : EditorWindow
    {
        private const string DEFINE_TTSDK = "TTSDK_MIX_ENGINE";
        private const string TIKTOK_DOCS =
            "https://developers.tiktok.com/doc/minigame-unity-sdk-quick-start";

        [MenuItem("IAP TikTok Setup/Integration Checklist", false, 1)]
        public static void Open()
        {
            var w = GetWindow<TikTokIntegrationChecklist>(false, "TikTok Integration");
            w.minSize = new Vector2(460, 520);
            w.Refresh();
        }

        // ─── Probed state ───────────────────────────────────────

        private bool _ttPluginPresent, _ttDefineSet;
        private TikTokSDK _sdk;
        private bool _sceneDirty;
        private bool _needsRepair;
        private bool _sceneOnDisk;
        private BuildTarget _target;

        private string _testState = "";     // "", "running", "ok", "fail"
        private string _testMessage = "";
        private UnityWebRequest _testReq;

        private void OnEnable() => Refresh();
        private void OnFocus() => Refresh();

        private void OnDisable()
        {
            if (_testReq != null) { _testReq.Dispose(); _testReq = null; }
            EditorApplication.update -= PumpTest;
        }

        private void Refresh()
        {
            // The plugin is detected by type, not by define. A define can be set
            // on a project that never imported the package, and that combination
            // fails to compile — which is exactly the state worth reporting.
            _ttPluginPresent = AppDomain.CurrentDomain.GetAssemblies()
                .Any(a => { try { return a.GetType("TTSDK.TT") != null; } catch { return false; } });

            // Re-read from disk, not from a cached static: importing the plugin
            // or switching the SDK between source and .tgz both change these
            // without necessarily reloading this window.
            TikTokVersionInfo.Refresh();

            _target = EditorUserBuildSettings.activeBuildTarget;
            var defines = CurrentDefines();
            _ttDefineSet = defines.Contains(DEFINE_TTSDK);

            _sdk = FindSdkInScene();
            _needsRepair = TikTokSDKSetupTool.NeedsRepair();
            var active = UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene();
            _sceneDirty = active.isDirty;
            // A scene with no path has never been written, so the SDK object
            // really would be gone next launch. Once it has been saved, later
            // edits marking it dirty again are just editing — reporting that as
            // a failed step made the row flip red on every revisit and taught
            // people to save to silence it.
            _sceneOnDisk = !string.IsNullOrEmpty(active.path);

            Repaint();
        }

        private static TikTokSDK FindSdkInScene()
        {
#if UNITY_2023_1_OR_NEWER
            return UnityEngine.Object.FindFirstObjectByType<TikTokSDK>();
#else
            return UnityEngine.Object.FindObjectOfType<TikTokSDK>();
#endif
        }

        // ─── Defines ────────────────────────────────────────────

        private static BuildTargetGroup Group =>
            BuildPipeline.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);

        private static string CurrentDefines() =>
            PlayerSettings.GetScriptingDefineSymbolsForGroup(Group) ?? "";

        private static void AddDefine(string symbol)
        {
            var list = CurrentDefines().Split(';').Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
            if (list.Contains(symbol)) return;
            list.Add(symbol);
            PlayerSettings.SetScriptingDefineSymbolsForGroup(Group, string.Join(";", list));
        }

        private static void RemoveDefine(string symbol)
        {
            var list = CurrentDefines().Split(';')
                .Where(s => !string.IsNullOrWhiteSpace(s) && s != symbol).ToList();
            PlayerSettings.SetScriptingDefineSymbolsForGroup(Group, string.Join(";", list));
        }

        // ─── GUI ────────────────────────────────────────────────

        private Vector2 _scroll;

        /// <summary>
        /// Queue work that changes what this window draws. IMGUI walks OnGUI
        /// twice — Layout counts the controls, Repaint draws them — and both
        /// walks have to produce the same set. Re-probing inline flipped
        /// branches mid-pass, so Repaint drew a different window than Layout had
        /// measured and IMGUI reported an invalid layout state.
        /// </summary>
        private Action _pending;
        private void Defer(Action a) { _pending = a; }

        private SerializedObject _so;
        private string _drawTestState = "";
        private string _drawTestMessage = "";

        private void OnGUI()
        {
            // The credential probe answers on EditorApplication.update, which can
            // land between the two walks; render what was true at Layout.
            if (Event.current.type == EventType.Layout)
            {
                _drawTestState = _testState;
                _drawTestMessage = _testMessage;
            }

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            EditorGUILayout.Space(6);

            EditorGUILayout.LabelField("Integration checklist", EditorStyles.boldLabel);
            // The project is named, not assumed. Every path below is written
            // project-relative, which reads identically in two projects that
            // have different packages installed — and reading one window while
            // thinking of the other project is a genuinely easy mistake.
            EditorGUILayout.LabelField(
                $"Project: {ProjectName}   ·   Build target: {_target}. Defines are per-target, " +
                "so switching platform changes what this window reports.",
                EditorStyles.wordWrappedMiniLabel);
            EditorGUILayout.Space(8);

            DrawVersions();

            DrawTikTokPlugin();
            DrawSceneSetup();
            DrawCredentials();
            DrawOptional();

            EditorGUILayout.Space(10);
            if (GUILayout.Button("Re-check", GUILayout.Height(24))) Defer(Refresh);

            EditorGUILayout.EndScrollView();

            if (_pending != null && Event.current.type == EventType.Repaint)
            {
                var run = _pending;
                _pending = null;
                run();
            }
        }

        // ── Versions ───────────────────────────────────────────

        /// <summary>
        /// Both versions, above the checklist rather than inside it.
        ///
        /// They are not a step — nothing here passes or fails — but they are the
        /// first thing asked for when any of the steps below misbehave, and the
        /// answer used to mean opening two package.json files by hand.
        /// </summary>
        private void DrawVersions()
        {
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                VersionRow("HS TikTok SDK",
                    TikTokVersionInfo.HsVersion,
                    TikTokVersionInfo.HsSource,
                    TikTokVersionInfo.HsPath);

                VersionRow("TikTok TTSDK",
                    TikTokVersionInfo.TtPackageVersion,
                    TikTokVersionInfo.TtApiVersion != "" ? "API " + TikTokVersionInfo.TtApiVersion : "",
                    TikTokVersionInfo.TtPath +
                        (TikTokVersionInfo.TtBinary != "" ? "  ·  " + TikTokVersionInfo.TtBinary : ""));

                // TikTok does not always fill their version in. A drop that
                // declares 1.0.0 is an older one that left the field alone, not
                // a first release — and both drops embed the same changelog, so
                // the API number cannot tell them apart either. The file date on
                // the line above can.
                if (TikTokVersionInfo.TtPackageVersion == "1.0.0")
                    EditorGUILayout.LabelField(
                        "TikTok left the version unset in this drop — go by the ttsdk.dll date above. " +
                        "Their later packages declare it properly (e.g. 1.1.5-Release).",
                        EditorStyles.wordWrappedMiniLabel);

                if (GUILayout.Button("Copy versions for a bug report"))
                    Defer(() =>
                    {
                        EditorGUIUtility.systemCopyBuffer = TikTokVersionInfo.Report();
                        Debug.Log("[HS.TikTokSDK] Versions copied to the clipboard:\n" + TikTokVersionInfo.Report());
                    });
            }
            EditorGUILayout.Space(10);
        }

        private static string ProjectName =>
            new System.IO.DirectoryInfo(
                System.IO.Path.GetDirectoryName(Application.dataPath) ?? ".").Name;

        private static void VersionRow(string name, string version, string note, string path)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(name, GUILayout.Width(120));

                var style = new GUIStyle(EditorStyles.boldLabel);
                // Amber, not red: a missing plugin is step 1's verdict to give,
                // and two rows shouting the same failure reads as two failures.
                if (version.StartsWith("not installed") || version.StartsWith("unknown") ||
                    version.StartsWith("could not"))
                    style.normal.textColor = new Color(0.75f, 0.6f, 0.15f);

                EditorGUILayout.LabelField(version, style, GUILayout.Width(140));
                EditorGUILayout.LabelField(note, EditorStyles.miniLabel);
            }

            if (!string.IsNullOrEmpty(path))
            {
                using (new EditorGUI.IndentLevelScope())
                    EditorGUILayout.LabelField(path, EditorStyles.wordWrappedMiniLabel);
            }
        }

        // ── 1 ──────────────────────────────────────────────────

        private void DrawTikTokPlugin()
        {
            bool ok = _ttPluginPresent && _ttDefineSet;
            Header(1, "TikTok SDK for Unity", ok);

            using (new EditorGUI.IndentLevelScope())
            {
                // Presence is the requirement, not a version. The SDK uses only
                // the plugin's stable core (login, ads, init, mock), verified
                // member-by-member against drops a year apart — so naming a
                // version here read as "you need exactly this one", which is
                // wrong and sent people chasing an upgrade they did not need.
                // The versions box above still REPORTS what is installed.
                Line("Package imported", _ttPluginPresent);
                Line($"{DEFINE_TTSDK} define", _ttDefineSet);

                if (!_ttPluginPresent)
                {
                    EditorGUILayout.HelpBox(
                        "TikTok distributes this as a .unitypackage through your TikTok operations " +
                        "representative — there is no public download, so it cannot be installed " +
                        "automatically. Ask them for the com.tiktok.minigame .unitypackage and " +
                        "import it below. Any recent drop works — the SDK relies only on the " +
                        "plugin's stable core APIs.",
                        MessageType.Warning);

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button("Import .unitypackage…"))
                        {
                            var path = EditorUtility.OpenFilePanel(
                                "Select the TikTok MiniGame unitypackage", "", "unitypackage");
                            if (!string.IsNullOrEmpty(path))
                                AssetDatabase.ImportPackage(path, true);
                        }
                        if (GUILayout.Button("TikTok docs")) Application.OpenURL(TIKTOK_DOCS);
                    }
                }
                else if (!_ttDefineSet)
                {
                    EditorGUILayout.HelpBox(
                        "The plugin is present but the define is not set, so missions and the " +
                        "native ad path compile out. Without it they report success without ever " +
                        "calling TikTok, which looks like everything works.",
                        MessageType.Warning);
                    if (GUILayout.Button($"Add {DEFINE_TTSDK} for {_target}")) Defer(() => { AddDefine(DEFINE_TTSDK); Refresh(); });
                }
                else if (!_ttPluginPresent && _ttDefineSet)
                {
                    EditorGUILayout.HelpBox(
                        "The define is set but the plugin is missing — this combination does not " +
                        "compile. Import the package or remove the define.", MessageType.Error);
                    if (GUILayout.Button($"Remove {DEFINE_TTSDK}")) Defer(() => { RemoveDefine(DEFINE_TTSDK); Refresh(); });
                }
            }
            EditorGUILayout.Space(10);
        }

        // ── 2 ──────────────────────────────────────────────────

        private void DrawSceneSetup()
        {
            bool present = _sdk != null;
            bool atRoot = present && _sdk.transform.parent == null;
            bool named = present && _sdk.gameObject.name == "HS_TikTokSDK";
            bool ok = present && atRoot && named && _sceneOnDisk;

            Header(2, "SDK object in the scene", ok);

            using (new EditorGUI.IndentLevelScope())
            {
                Line("Object present", present);
                if (present)
                {
                    Line("At the scene root", atRoot);
                    Line("Named HS_TikTokSDK", named);
                    Line("Scene saved to disk", _sceneOnDisk);
                }

                if (!present)
                {
                    // An object called HS_TikTokSDK with no TikTokSDK on it is
                    // not "missing" — it is broken, and saying "missing" sent
                    // people to a button that then refused because the object
                    // was right there.
                    if (_needsRepair)
                    {
                        EditorGUILayout.HelpBox(
                            "The SDK object is in the scene but its scripts are missing. That happens " +
                            "when the SDK is swapped between the source package and the DLL package: a " +
                            "scene stores a script by guid, and a .cs file's guid is not the assembly's. " +
                            "TikTokMissions survives because it ships as source in both.\n\n" +
                            "Repair removes the broken components and puts the real ones back, with the " +
                            "credentials this project last used.",
                            MessageType.Warning);

                        if (GUILayout.Button("Repair SDK object"))
                            Defer(() => { TikTokSDKSetupTool.SetupSDK(); Refresh(); });
                    }
                    else if (GUILayout.Button("Setup SDK in Scene"))
                    {
                        Defer(() => { TikTokSDKSetupTool.SetupSDK(); Refresh(); });
                    }
                }
                else
                {
                    if (!atRoot || !named)
                    {
                        EditorGUILayout.HelpBox(
                            "The WebGL bridge finds this object by name at the scene root. Renamed " +
                            "or reparented, it still runs — but ad and payment callbacks never " +
                            "arrive, and nothing reports it.", MessageType.Error);
                        if (GUILayout.Button("Fix name and parent"))
                            Defer(() =>
                            {
                                Undo.RecordObject(_sdk.gameObject, "Fix SDK object");
                                _sdk.transform.SetParent(null);
                                _sdk.gameObject.name = "HS_TikTokSDK";
                                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(
                                    UnityEditor.SceneManagement.EditorSceneManager.GetActiveScene());
                                Refresh();
                            });
                    }

                    if (!_sceneOnDisk || _sceneDirty)
                    {
                        EditorGUILayout.HelpBox(_sceneOnDisk
                            ? "Unsaved edits in this scene — normal while working, but save before quitting."
                            : "This scene has never been saved, so the SDK object would be gone next launch.",
                            _sceneOnDisk ? MessageType.Info : MessageType.Warning);
                        if (GUILayout.Button("Save scene"))
                            Defer(() => { UnityEditor.SceneManagement.EditorSceneManager.SaveOpenScenes(); Refresh(); });
                    }

                    if (GUILayout.Button("Select in Hierarchy")) Selection.activeGameObject = _sdk.gameObject;
                }
            }
            EditorGUILayout.Space(10);
        }

        // ── 3 ──────────────────────────────────────────────────

        private void DrawCredentials()
        {
            bool present = _sdk != null;
            string gameId = present ? _sdk.gameId : "";
            string sdkKey = present ? _sdk.sdkKey : "";

            bool hasGame = !string.IsNullOrWhiteSpace(gameId);
            bool hasKey = !string.IsNullOrWhiteSpace(sdkKey);
            bool keyShape = hasKey && (sdkKey.StartsWith("sk_live_") || sdkKey.StartsWith("sk_test_"));
            bool ok = hasGame && keyShape && _drawTestState == "ok";

            Header(3, "Credentials", ok);

            using (new EditorGUI.IndentLevelScope())
            {
                if (!present)
                {
                    EditorGUILayout.LabelField("Complete step 2 first.", EditorStyles.miniLabel);
                    EditorGUILayout.Space(10);
                    return;
                }

                // Drawn through SerializedObject rather than a plain TextField.
                // A TextField keeps its own edit buffer, and writing the value
                // back to the component on every keystroke leaves that buffer
                // describing a string the field no longer shows — which is how a
                // pasted key came out duplicated. SerializedObject owns the
                // buffer, the undo entry and the dirty flag, so none of that is
                // hand-managed here.
                if (_so == null || _so.targetObject != _sdk) _so = new SerializedObject(_sdk);
                _so.Update();

                var pGameId = _so.FindProperty("gameId");
                var pSdkKey = _so.FindProperty("sdkKey");
                EditorGUILayout.PropertyField(pGameId, new GUIContent("Game Id"));
                EditorGUILayout.PropertyField(pSdkKey, new GUIContent("Sdk Key"));

                if (_so.ApplyModifiedProperties())
                {
                    // The previous result described the old credentials.
                    _testState = "";
                    _testMessage = "";
                    Defer(Refresh);
                }

                gameId = pGameId.stringValue;
                sdkKey = pSdkKey.stringValue;
                hasGame = !string.IsNullOrWhiteSpace(gameId);
                hasKey = !string.IsNullOrWhiteSpace(sdkKey);
                keyShape = hasKey && (sdkKey.StartsWith("sk_live_") || sdkKey.StartsWith("sk_test_"));

                // Kept so a repair can put them back — a missing script takes
                // its serialized values with it, and an sk_live_ key is not
                // something anyone should have to go and find twice.
                if (hasGame && keyShape) TikTokSDKSetupTool.RememberCredentials(gameId, sdkKey);

                Line("Game Id set", hasGame);
                Line("Sdk Key set", hasKey);
                if (hasKey) Line("Key looks like sk_live_ / sk_test_", keyShape);

                if (!hasGame || !hasKey)
                {
                    EditorGUILayout.HelpBox(
                        "Both values come from the developer dashboard — the Integrate page has a " +
                        "copy button for each. Paste them above; they are written straight to the " +
                        "HS_TikTokSDK object.",
                        MessageType.Info);
                    EditorGUILayout.Space(10);
                    return;
                }



                // Checked on open rather than on demand: a button that has not
                // been pressed leaves the one question this step exists to
                // answer unanswered, and looking correct is not the same as
                // working.
                if (_drawTestState == "" && Event.current.type == EventType.Layout)
                    Defer(() => StartTest(_sdk.gameId));

                string status =
                    _drawTestState == "ok"      ? "OK" :
                    _drawTestState == "fail"    ? "FAILED" :
                    _drawTestState == "running" ? "checking…" : "…";
                Line("Connection: " + status, _drawTestState == "ok",
                     warnOnly: _drawTestState != "fail");

                using (new EditorGUI.DisabledScope(_drawTestState == "running"))
                    if (GUILayout.Button("Re-test connection")) Defer(() => StartTest(_sdk.gameId));

                // Only the failure needs explaining; a working connection does
                // not need a paragraph about it.
                if (_drawTestState == "fail")
                    EditorGUILayout.HelpBox(_drawTestMessage, MessageType.Error);

                // Step 2 treats a dirty scene as ordinary editing, which it is —
                // but credentials living only in memory is the one unsaved change
                // that costs you the setup, so it gets a prompt of its own.
                if (_sceneDirty)
                {
                    EditorGUILayout.HelpBox(
                        "These are not saved yet — reopening the scene would lose them.",
                        MessageType.Warning);
                    if (GUILayout.Button("Save scene"))
                        Defer(() =>
                        {
                            UnityEditor.SceneManagement.EditorSceneManager.SaveOpenScenes();
                            Refresh();
                        });
                }
            }
            EditorGUILayout.Space(10);
        }

        // ── 4 ──────────────────────────────────────────────────

        private void DrawOptional()
        {
            bool debugOn = _sdk != null && _sdk.enableDebugLogs;

            Header(4, "Before you ship", true, muted: true);
            using (new EditorGUI.IndentLevelScope())
            {
                Line("Building for WebGL", _target == BuildTarget.WebGL, warnOnly: true);
                if (_target != BuildTarget.WebGL)
                    EditorGUILayout.LabelField(
                        "TikTok Mini Games are WebGL. Other targets run, but always in test mode.",
                        EditorStyles.wordWrappedMiniLabel);

                if (_sdk == null) return;

                // Warned about here rather than switched off automatically.
                //
                // Silencing these in every build was the obvious move and the
                // wrong one: inside the TikTok app there is no console, no
                // profiler and no debugger, and the player log is the only
                // account of what the SDK did. The QA harness mirrors its whole
                // log to Debug.Log for exactly that reason. Turning them off for
                // a partner would take away the one tool that works on device.
                //
                // Nothing here carries a credential — the session token and the
                // SDK key are never logged, only the openId — so leaving them on
                // costs noise and a little CPU, not a leak. That is a decision a
                // partner is entitled to make; it just has to be visible at the
                // moment they are shipping, which is what this row is for.
                Line("Debug logs off", !debugOn, warnOnly: true);

                if (_so == null || _so.targetObject != _sdk) _so = new SerializedObject(_sdk);
                _so.Update();
                var pLogs = _so.FindProperty("enableDebugLogs");
                EditorGUILayout.PropertyField(pLogs, new GUIContent("Enable Debug Logs"));
                if (_so.ApplyModifiedProperties()) Defer(Refresh);

                if (debugOn)
                    EditorGUILayout.HelpBox(
                        "Debug logs are on. Fine while you are building — they are the only trace " +
                        "you get inside the TikTok app, and no credential is written to them. " +
                        "Turn them off for a public release to save the noise.",
                        MessageType.Info);
            }
        }

        // ─── Credential test ────────────────────────────────────
        //
        // /api/shop/items is the right probe: it is the one endpoint that needs
        // the SDK key and signature but no session, so it separates "credentials
        // are wrong" from "login is broken" — which a login attempt cannot.

        private void StartTest(string gameId)
        {
            _testState = "running";
            _testMessage = "";

            string body = JsonUtility.ToJson(new ShopProbe { game_id = gameId });
            // Pass the component explicitly — TikTokSDK.Instance is assigned in
            // Awake, so outside play mode there is no singleton to read.
            _testReq = TikTokHttp.Post("/api/shop/items", body, _sdk);

            if (_testReq == null)
            {
                _testState = "fail";
                _testMessage = "Could not build the request — is the SDK object in the scene?";
                return;
            }

            // Unity's Mono ships its own CA bundle, and on macOS it is routinely
            // stale or empty — a perfectly valid certificate then fails with
            // "SSL CA certificate error" in the Editor while curl on the same
            // machine succeeds. Accepting the chain here keeps that from being
            // reported as a credentials problem, which is the one thing this
            // window exists to answer.
            //
            // Safe because of where it lives: this is the Editor assembly, it is
            // attached to this diagnostic request alone, and nothing in Runtime/
            // does it — so no player build can carry it.
            _testReq.certificateHandler = new AcceptAll();
            _testReq.disposeCertificateHandlerOnDispose = true;

            _testReq.SendWebRequest();
            EditorApplication.update += PumpTest;
        }

        private class AcceptAll : CertificateHandler
        {
            protected override bool ValidateCertificate(byte[] certificateData) => true;
        }

        private void PumpTest()
        {
            if (_testReq == null || !_testReq.isDone) return;

            EditorApplication.update -= PumpTest;

            long code = _testReq.responseCode;
            string payload = _testReq.downloadHandler != null ? _testReq.downloadHandler.text : "";
            bool transportOk = TikTokHttp.IsSuccess(_testReq);
            string where = $"\n\nRequested: {_testReq.url}";

            // The API answers in JSON, always. HTML back means something other
            // than the backend replied — a local dev server holding the
            // hostname, a proxy, an /etc/hosts entry — and reading its status
            // code as though the API sent it produces exactly the wrong advice:
            // a proxy's 404 page becomes "check the Game Id" when the Game Id
            // was never seen by anything.
            bool looksLikeHtml = !string.IsNullOrEmpty(payload) &&
                                 payload.TrimStart().StartsWith("<", StringComparison.Ordinal);

            if (looksLikeHtml)
            {
                _testState = "fail";
                _testMessage =
                    $"Something other than the SDK backend answered (HTTP {code}, HTML not JSON).\n\n" +
                    "This host is being intercepted on this machine — a local web server such as " +
                    "Laravel Herd or MAMP holding port 443, an /etc/hosts entry, or a proxy. The " +
                    "credentials were never checked.\n\n" +
                    "Confirm with:  curl -i " + _testReq.url + where + "\n\n" + Trim(payload, 200);
            }
            else if (transportOk)
            {
                _testState = "ok";
                _testMessage = "";
            }
            else if (code == 401 || code == 403)
            {
                _testState = "fail";
                _testMessage = $"Rejected (HTTP {code}). The Sdk Key does not match this Game Id, " +
                               $"or the game is not active.\n\n{Trim(payload)}" + where;
            }
            else if (code == 404)
            {
                _testState = "fail";
                _testMessage = $"Game not found (HTTP 404). Check the Game Id.\n\n{Trim(payload)}" + where;
            }
            else if (code == 0)
            {
                _testState = "fail";
                _testMessage = $"Could not reach the backend: {_testReq.error}\n" +
                               "Either the gateway is unreachable, or this host is intercepted " +
                               "locally by a server presenting its own certificate." + where;
            }
            else
            {
                _testState = "fail";
                _testMessage = $"HTTP {code}: {_testReq.error}\n\n{Trim(payload)}" + where;
            }

            _testReq.Dispose();
            _testReq = null;
            Repaint();
        }

        [Serializable]
        private struct ShopProbe { public string game_id; }

        // ─── Small helpers ──────────────────────────────────────

        private static void Header(int step, string title, bool ok, bool muted = false)
        {
            string mark = muted ? "•" : (ok ? "✔" : "✖");
            var style = new GUIStyle(EditorStyles.boldLabel);
            if (!muted) style.normal.textColor = ok ? new Color(0.15f, 0.65f, 0.35f) : new Color(0.8f, 0.25f, 0.25f);
            EditorGUILayout.LabelField($"{mark}  {step}. {title}", style);
        }

        private static void Line(string label, bool ok, bool warnOnly = false)
        {
            var style = new GUIStyle(EditorStyles.label);
            if (!ok) style.normal.textColor = warnOnly
                ? new Color(0.75f, 0.6f, 0.15f)
                : new Color(0.8f, 0.25f, 0.25f);
            EditorGUILayout.LabelField($"{(ok ? "✔" : (warnOnly ? "—" : "✖"))}  {label}", style);
        }


        private static string Trim(string s, int max = 300)
        {
            if (string.IsNullOrEmpty(s)) return "";
            return s.Length <= max ? s : s.Substring(0, max) + "…";
        }
    }
}
